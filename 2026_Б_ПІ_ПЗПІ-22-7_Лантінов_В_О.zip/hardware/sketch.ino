#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <ArduinoJson.h>

// WiFi credentials (Wokwi default)
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// HiveMQ credentials
const char* mqtt_server = "719e192603794d6882b017dac7fe095c.s1.eu.hivemq.cloud";
const int mqtt_port = 8883;
const char* mqtt_user = "lun44";
const char* mqtt_pass = "3hDQtURd9juniYJ";
const char* mqtt_topic = "telemetry/truck_01";

WiFiClientSecure espClient;
PubSubClient client(espClient);

// Sensors
#define DHTPIN 4
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);

Adafruit_MPU6050 mpu;

#define POT_PIN 34

// Simulated GPS
float current_lat = 50.4501;
float current_lon = 30.5234;

void setup_wifi() {
  delay(10);
  Serial.println();
  Serial.print("Connecting to ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi connected");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());
}

void reconnect() {
  while (!client.connected()) {
    Serial.print("Attempting MQTT connection...");
    String clientId = "ESP32Client-";
    clientId += String(random(0xffff), HEX);
    if (client.connect(clientId.c_str(), mqtt_user, mqtt_pass)) {
      Serial.println("connected");
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" try again in 5 seconds");
      delay(5000);
    }
  }
}

void setup() {
  Serial.begin(115200);
  
  // Initialize sensors
  dht.begin();
  
  if (!mpu.begin()) {
    Serial.println("Failed to find MPU6050 chip");
  } else {
    Serial.println("MPU6050 Found!");
    mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
    mpu.setGyroRange(MPU6050_RANGE_500_DEG);
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
  }
  
  pinMode(POT_PIN, INPUT);

  // Configure Secure Client
  espClient.setInsecure(); // Bypass SSL certificate validation for simplicity in Wokwi

  setup_wifi();
  client.setServer(mqtt_server, mqtt_port);
}

void loop() {
  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  // Read Sensors
  float t = dht.readTemperature();
  
  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);
  
  int fuel_raw = analogRead(POT_PIN);
  float fuel_level = (fuel_raw / 4095.0) * 100.0; // 0-100%
  
  // Simulate GPS movement slightly
  current_lat += (random(-10, 11) / 100000.0);
  current_lon += (random(-10, 11) / 100000.0);

  // Prepare JSON payload
  JsonDocument doc;
  doc["deviceId"] = "truck_01";
  
  JsonObject gps = doc.createNestedObject("gps");
  gps["lat"] = current_lat;
  gps["lon"] = current_lon;
  
  JsonObject accel = doc.createNestedObject("accel");
  accel["x"] = a.acceleration.x;
  accel["y"] = a.acceleration.y;
  accel["z"] = a.acceleration.z;
  
  doc["temperature"] = t;
  doc["fuel_level"] = fuel_level;
  doc["timestamp"] = millis();

  char jsonBuffer[256];
  serializeJson(doc, jsonBuffer);
  
  Serial.print("Publishing message: ");
  Serial.println(jsonBuffer);
  client.publish(mqtt_topic, jsonBuffer);
  
  delay(1000); // Publish every 1 second
}
