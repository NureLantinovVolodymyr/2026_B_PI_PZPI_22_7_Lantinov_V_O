#include <Arduino.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <Wire.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <ArduinoJson.h>

// WiFi credentials (Wokwi default)
const char* ssid = "Wokwi-GUEST";
const char* password = "";

// HiveMQ credentials
const char* mqtt_server = "719e192603794d6882b017dac7fe095c.s1.eu.hivemq.cloud";
const int mqtt_port = 8883;
const char* mqtt_user = "lun44";
const char* mqtt_pass = "3hDQtURd9juniYJ";
const char* mqtt_topic = "telemetry/truck_01";

WiFiClientSecure espClient;
PubSubClient client(espClient);

// Sensors
#define DHTPIN 4
#define DHTTYPE DHT22
DHT dht(DHTPIN, DHTTYPE);

Adafruit_MPU6050 mpu;

#define POT_PIN 34
#define JOY_HORZ_PIN 32
#define JOY_VERT_PIN 33

// Simulated GPS (starting near Kyiv)
float current_lat = 50.4501;
float current_lon = 30.5234;

void mqttCallback(char* topic, byte* payload, unsigned int length) {
  String topicStr = String(topic);
  if (topicStr == "telemetry/truck_01/set_location") {
    JsonDocument doc;
    deserializeJson(doc, payload, length);
    if (doc.containsKey("lat") && doc.containsKey("lon")) {
      current_lat = doc["lat"].as<float>();
      current_lon = doc["lon"].as<float>();
      Serial.print("[MQTT] Received new location: ");
      Serial.print(current_lat, 5);
      Serial.print(", ");
      Serial.println(current_lon, 5);
    }
  }
}

void setup_wifi() {
  delay(10);
  Serial.println();
  Serial.print("Connecting to WiFi: ");
  Serial.println(ssid);

  WiFi.begin(ssid, password);

  int retries = 0;
  while (WiFi.status() != WL_CONNECTED && retries < 20) {
    delay(500);
    Serial.print(".");
    retries++;
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWiFi connected! IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nWiFi connection FAILED");
  }
}

void reconnect() {
  int attempts = 0;
  while (!client.connected() && attempts < 5) {
    Serial.print("Attempting MQTT connection...");
    String clientId = "ESP32-FleetSync-";
    clientId += String(random(0xffff), HEX);
    if (client.connect(clientId.c_str(), mqtt_user, mqtt_pass)) {
      Serial.println("connected to HiveMQ!");
      client.subscribe("telemetry/truck_01/set_location");
      client.publish("telemetry/truck_01/request_location", "{}");
    } else {
      Serial.print("failed, rc=");
      Serial.print(client.state());
      Serial.println(" — retrying in 3s");
      delay(3000);
      attempts++;
    }
  }
}

void setup() {
  Serial.begin(115200);
  Serial.println("=== FleetSync ESP32 Boot ===");

  // Initialize DHT22
  dht.begin();
  Serial.println("DHT22 initialized");

  // Initialize MPU6050
  Wire.begin();
  if (!mpu.begin()) {
    Serial.println("WARNING: MPU6050 not found!");
  } else {
    Serial.println("MPU6050 initialized");
    mpu.setAccelerometerRange(MPU6050_RANGE_8_G);
    mpu.setGyroRange(MPU6050_RANGE_500_DEG);
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
  }

  pinMode(POT_PIN, INPUT);

  // Bypass SSL for Wokwi simulation
  espClient.setInsecure();

  setup_wifi();
  client.setServer(mqtt_server, mqtt_port);
  client.setCallback(mqttCallback);
  client.setBufferSize(512);

  Serial.println("Setup complete. Starting telemetry loop...");
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("WiFi lost, reconnecting...");
    setup_wifi();
    return;
  }

  if (!client.connected()) {
    reconnect();
  }
  client.loop();

  // === Read Sensors ===
  sensors_event_t a, g, temp_event;
  mpu.getEvent(&a, &g, &temp_event);

  // === Fuel & Movement Logic ===
  static float simulated_fuel = 100.0;

  // Refuel if potentiometer is turned up (simulates a gas station)
  int potValue = analogRead(POT_PIN);
  if (potValue > 3000) {
    simulated_fuel += 5.0; // Refuel quickly if knob is turned to max
    if (simulated_fuel > 100.0) simulated_fuel = 100.0;
  }

  // Read Joystick
  int joyX = analogRead(JOY_HORZ_PIN);
  int joyY = analogRead(JOY_VERT_PIN);
  
  // Calculate speed based on how far joystick is pushed from center (2048)
  float speedX = 0;
  float speedY = 0;
  int deadzone = 300;
  
  if (abs(joyX - 2048) > deadzone) speedX = (float)abs(joyX - 2048) / 2048.0;
  if (abs(joyY - 2048) > deadzone) speedY = (float)abs(joyY - 2048) / 2048.0;
  
  float totalSpeed = sqrt(speedX * speedX + speedY * speedY);

  // Consume fuel based on speed and a small idle consumption
  float idleConsumption = 0.01;
  float activeConsumption = totalSpeed * 0.1;
  
  if (simulated_fuel > 0) {
    simulated_fuel -= (idleConsumption + activeConsumption);
    if (simulated_fuel < 0) simulated_fuel = 0;
  }

  // Move GPS only if there is fuel left
  if (simulated_fuel > 0) {
    float max_step = 0.0002; // max distance per tick
    if (joyX < 2048 - deadzone) current_lon -= speedX * max_step;
    if (joyX > 2048 + deadzone) current_lon += speedX * max_step;
    
    // Wokwi joystick Y is inverted (up is low value)
    if (joyY < 2048 - deadzone) current_lat += speedY * max_step;
    if (joyY > 2048 + deadzone) current_lat -= speedY * max_step;
  }

  float fuel_level = simulated_fuel;
  float current_speed_kmh = totalSpeed * 85.0; // max ~120 km/h
  
  static float simulated_temp = 20.0;
  if (current_speed_kmh > 5.0) {
    simulated_temp += (current_speed_kmh / 100.0); // Heat up
    if (simulated_temp > 95.0) simulated_temp = 95.0;
  } else {
    simulated_temp -= 0.5; // Cool down
    if (simulated_temp < 20.0) simulated_temp = 20.0;
  }

  // === Build JSON Payload ===
  JsonDocument doc;
  doc["deviceId"] = "truck_01";

  JsonObject gps = doc["gps"].to<JsonObject>();
  gps["lat"] = current_lat;
  gps["lon"] = current_lon;

  JsonObject accel = doc["accel"].to<JsonObject>();
  accel["x"] = a.acceleration.x;
  accel["y"] = a.acceleration.y;
  accel["z"] = a.acceleration.z;

  doc["temperature"] = simulated_temp;
  doc["fuel_level"] = fuel_level;
  doc["speed"] = current_speed_kmh;
  doc["ts"] = millis();

  char jsonBuffer[512];
  serializeJson(doc, jsonBuffer);

  Serial.print("[MQTT] >> ");
  Serial.println(jsonBuffer);

  bool published = client.publish(mqtt_topic, jsonBuffer);
  if (!published) {
    Serial.println("[MQTT] Publish FAILED");
  }

  delay(2000); // Send every 2 seconds
}
