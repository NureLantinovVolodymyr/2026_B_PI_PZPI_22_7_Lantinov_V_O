'use client';

import React, { useState } from 'react';
import { Search, MapPin } from 'lucide-react';

const MAPBOX_TOKEN = process.env.NEXT_PUBLIC_MAPBOX_TOKEN;

export default function CitySearch() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const handleSearch = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setQuery(val);
    if (val.length < 3) {
      setResults([]);
      setIsOpen(false);
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`https://api.mapbox.com/geocoding/v5/mapbox.places/${encodeURIComponent(val)}.json?access_token=${MAPBOX_TOKEN}&types=place&autocomplete=true&limit=5`);
      const data = await res.json();
      if (data.features) {
        setResults(data.features);
        setIsOpen(true);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const selectCity = async (feature: any) => {
    setQuery(feature.place_name);
    setIsOpen(false);
    
    // Coordinates are [lon, lat] in Mapbox
    const [lon, lat] = feature.center;
    
    try {
      await fetch('/api/set-location', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ lat, lon })
      });
      console.log('Location updated successfully!');
    } catch (err) {
      console.error('Failed to update location', err);
    }
  };

  return (
    <div className="relative w-full max-w-md z-50 mb-4">
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-gray-400" />
        </div>
        <input
          type="text"
          className="block w-full pl-10 pr-3 py-2 border border-gray-700 rounded-xl leading-5 bg-black/50 text-gray-200 placeholder-gray-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm transition-colors"
          placeholder="Search for a city to start..."
          value={query}
          onChange={handleSearch}
        />
        {loading && (
          <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
            <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          </div>
        )}
      </div>

      {isOpen && results.length > 0 && (
        <ul className="absolute z-50 mt-1 w-full bg-[#111] border border-gray-700 rounded-xl shadow-2xl max-h-60 overflow-auto divide-y divide-gray-800">
          {results.map((feature) => (
            <li
              key={feature.id}
              className="cursor-pointer hover:bg-gray-800 px-4 py-3 text-sm text-gray-200 flex items-center space-x-2"
              onClick={() => selectCity(feature)}
            >
              <MapPin className="w-4 h-4 text-gray-400 shrink-0" />
              <span className="truncate">{feature.place_name}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
