'use client';

import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Plus, X, Truck } from 'lucide-react';

export default function DeviceManager({ devices, onDeviceAdded }: { devices: any[], onDeviceAdded: () => void }) {
  const [isOpen, setIsOpen] = useState(false);
  const [deviceId, setDeviceId] = useState('');
  const [name, setName] = useState('');
  const [model, setModel] = useState('');
  const [loading, setLoading] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [editingId, setEditingId] = useState('');
  const [editName, setEditName] = useState('');
  const [editModel, setEditModel] = useState('');

  useEffect(() => {
    setMounted(true);
  }, []);

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await fetch('/api/user/devices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ deviceId, name, model })
      });
      if (res.ok) {
        setIsOpen(false);
        setDeviceId('');
        setName('');
        setModel('');
        onDeviceAdded();
      } else {
        const data = await res.json();
        alert(data.error);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleEditSave = async (id: string) => {
    try {
      const res = await fetch('/api/user/devices', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ deviceId: id, name: editName, model: editModel })
      });
      if (res.ok) {
        setEditingId('');
        onDeviceAdded();
      }
    } catch(err) { console.error(err); }
  };

  const handleDelete = async (id: string) => {
    if(!confirm('Are you sure you want to delete this device?')) return;
    try {
      const res = await fetch(`/api/user/devices?deviceId=${id}`, { method: 'DELETE' });
      if (res.ok) {
        onDeviceAdded();
      }
    } catch(err) { console.error(err); }
  };

  const modal = isOpen && mounted ? createPortal(
    <div className="fixed inset-0 bg-[#FDFDFD]/90 backdrop-blur-sm z-[9999] flex items-center justify-center p-4">
      <div className="bg-white border-4 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] p-6 w-full max-w-md relative">
        <button onClick={() => setIsOpen(false)} className="absolute top-4 right-4 text-black hover:scale-110 transition-transform">
          <X className="w-6 h-6 stroke-[3]" />
        </button>
        
        <h2 className="text-2xl font-black uppercase tracking-tight mb-4 text-black">Manage Devices</h2>
        
        <div className="space-y-4 mb-8 max-h-40 overflow-y-auto pr-2">
          {devices.length === 0 ? (
            <p className="font-bold text-black border-2 border-black border-dashed p-4 text-center">You don't have any devices yet.</p>
          ) : (
            devices.map(d => (
              <div key={d.deviceId} className="bg-white border-4 border-black p-4 flex flex-col space-y-2 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                {editingId === d.deviceId ? (
                  <div className="flex flex-col space-y-3">
                    <input 
                      type="text" className="w-full bg-white border-2 border-black p-2 font-bold outline-none focus:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-shadow"
                      value={editName} onChange={e => setEditName(e.target.value)} placeholder="Custom Name"
                    />
                    <input 
                      type="text" className="w-full bg-white border-2 border-black p-2 font-bold outline-none focus:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] transition-shadow"
                      value={editModel} onChange={e => setEditModel(e.target.value)} placeholder="Car Model"
                    />
                    <div className="flex space-x-2">
                      <button onClick={() => setEditingId('')} className="flex-1 border-2 border-black font-black uppercase text-xs py-2 bg-gray-200 hover:bg-gray-300">Cancel</button>
                      <button onClick={() => handleEditSave(d.deviceId)} className="flex-1 border-2 border-black font-black uppercase text-xs py-2 bg-[#38b6ff] hover:bg-blue-400">Save</button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-12 h-12 border-2 border-black bg-[#FFDE59] flex items-center justify-center mr-4 shrink-0 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                        <Truck className="w-6 h-6 text-black" />
                      </div>
                      <div>
                        <p className="font-black text-lg truncate uppercase">{d.customName || d.name}</p>
                        <p className="font-medium text-sm truncate">{d.carModel || d.model} • ID: {d.deviceId}</p>
                      </div>
                    </div>
                    <div className="flex flex-col space-y-2">
                      <button 
                        onClick={() => { setEditingId(d.deviceId); setEditName(d.customName || d.name); setEditModel(d.carModel || d.model); }}
                        className="text-black font-black uppercase text-xs hover:underline decoration-2"
                      >Edit</button>
                      <button 
                        onClick={() => handleDelete(d.deviceId)}
                        className="text-[#FF3131] font-black uppercase text-xs hover:underline decoration-2"
                      >Delete</button>
                    </div>
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        <form onSubmit={handleAdd} className="space-y-4 border-t-4 border-black pt-6">
          <h3 className="text-xl font-black uppercase text-black mb-2">Add New Device</h3>
          <input 
            type="text" placeholder="Device ID (e.g. truck_01)" required
            className="w-full bg-white border-4 border-black p-3 font-bold placeholder-gray-500 focus:outline-none focus:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-shadow"
            value={deviceId} onChange={e => setDeviceId(e.target.value)}
          />
          <input 
            type="text" placeholder="Custom Name (e.g. My Ford)" required
            className="w-full bg-white border-4 border-black p-3 font-bold placeholder-gray-500 focus:outline-none focus:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-shadow"
            value={name} onChange={e => setName(e.target.value)}
          />
          <input 
            type="text" placeholder="Car Model (e.g. Ford F-150)" required
            className="w-full bg-white border-4 border-black p-3 font-bold placeholder-gray-500 focus:outline-none focus:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-shadow"
            value={model} onChange={e => setModel(e.target.value)}
          />
          <button 
            type="submit" disabled={loading}
            className="w-full bg-[#38b6ff] border-4 border-black text-black font-black uppercase py-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 transition-all mt-4"
          >
            {loading ? 'Adding...' : 'Bind Device'}
          </button>
        </form>
      </div>
    </div>,
    document.body
  ) : null;

  return (
    <>
      <button 
        onClick={() => setIsOpen(true)}
        className="bg-[#38b6ff] border-4 border-black text-black px-6 py-2 font-black uppercase tracking-wide shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 transition-all flex items-center"
      >
        <Plus className="w-5 h-5 mr-2 stroke-[3]" /> Add Device
      </button>

      {modal}
    </>
  );
}
