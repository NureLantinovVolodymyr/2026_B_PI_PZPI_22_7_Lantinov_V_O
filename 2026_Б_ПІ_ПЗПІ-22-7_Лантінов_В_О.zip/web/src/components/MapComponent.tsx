'use client';

import React, { useEffect, useRef } from 'react';
import mapboxgl from 'mapbox-gl';
import 'mapbox-gl/dist/mapbox-gl.css';

const MAPBOX_TOKEN = process.env.NEXT_PUBLIC_MAPBOX_TOKEN;

interface MapComponentProps {
  telemetry: any[];
  places?: any[];
  onPlaceClick?: (place: any) => void;
}

const geofenceGeoJSON: GeoJSON.Feature<GeoJSON.Polygon> = {
  type: 'Feature',
  properties: {},
  geometry: {
    type: 'Polygon',
    coordinates: [[
      [30.51, 50.44],
      [30.53, 50.44],
      [30.53, 50.46],
      [30.51, 50.46],
      [30.51, 50.44]
    ]]
  }
};

export default function MapComponent({ telemetry, places = [], onPlaceClick }: MapComponentProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<mapboxgl.Map | null>(null);
  const markers = useRef<{ [id: string]: mapboxgl.Marker }>({});
  const placeMarkers = useRef<{ [id: string]: mapboxgl.Marker }>({});

  useEffect(() => {
    if (!MAPBOX_TOKEN || !mapContainer.current) return;

    if (!map.current) {
      mapboxgl.accessToken = MAPBOX_TOKEN;
      map.current = new mapboxgl.Map({
        container: mapContainer.current,
        style: 'mapbox://styles/mapbox/dark-v11',
        center: [30.5234, 50.4501],
        zoom: 12
      });

      map.current.addControl(new mapboxgl.NavigationControl(), 'top-right');

      map.current.on('load', () => {
        if (!map.current) return;
        map.current.addSource('geofence-source', {
          type: 'geojson',
          data: geofenceGeoJSON
        });

        map.current.addLayer({
          id: 'geofence',
          type: 'fill',
          source: 'geofence-source',
          paint: {
            'fill-color': '#EF4444',
            'fill-opacity': 0.2,
            'fill-outline-color': '#EF4444'
          }
        });
      });
    }

    // Update markers
    telemetry.forEach(t => {
      if (!t.gps || !map.current) return;
      
      let marker = markers.current[t.deviceId];
      if (!marker) {
        const el = document.createElement('div');
        el.className = 'marker-container';
        el.innerHTML = `
          <div class="flex flex-col items-center">
            <div class="w-5 h-5 bg-blue-500 rounded-full border-2 border-white shadow-[0_0_15px_rgba(59,130,246,0.8)] animate-pulse"></div>
            <span class="text-xs font-bold text-white mt-1 bg-black/70 px-2 py-0.5 rounded backdrop-blur-sm">${t.deviceId}</span>
          </div>
        `;
        
        marker = new mapboxgl.Marker(el)
          .setLngLat([t.gps.lon, t.gps.lat])
          .addTo(map.current);
          
        markers.current[t.deviceId] = marker;
      } else {
        marker.setLngLat([t.gps.lon, t.gps.lat]);
      }
    });

    // Update place markers
    places.forEach(p => {
      if (!map.current) return;
      let pMarker = placeMarkers.current[p._id];
      if (!pMarker) {
        const el = document.createElement('div');
        el.className = 'place-marker-container cursor-pointer transition-transform hover:scale-125';
        el.innerHTML = `
          <div class="flex flex-col items-center">
            <div class="text-2xl drop-shadow-[0_0_10px_rgba(239,68,68,0.8)]">❤️</div>
            <span class="text-xs font-bold text-white mt-1 bg-black/80 px-2 py-0.5 rounded backdrop-blur-sm border border-red-500/30 whitespace-nowrap">${p.name}</span>
          </div>
        `;
        
        el.addEventListener('click', () => {
          if (onPlaceClick) onPlaceClick(p);
        });

        pMarker = new mapboxgl.Marker(el)
          .setLngLat([p.location.lon, p.location.lat])
          .addTo(map.current);
          
        placeMarkers.current[p._id] = pMarker;
      } else {
        // Update name if changed
        const span = pMarker.getElement().querySelector('span');
        if (span) span.innerText = p.name;
      }
    });
  }, [telemetry, places]);

  if (!MAPBOX_TOKEN) {
    return <div className="p-4 bg-red-100 text-red-600 rounded">Mapbox token is missing.</div>;
  }

  return (
    <div className="w-full h-full min-h-[400px] rounded-xl overflow-hidden shadow-[0_8px_30px_rgb(0,0,0,0.12)] border border-gray-800 relative z-0">
      <div ref={mapContainer} className="w-full h-full absolute inset-0" />
    </div>
  );
}
