'use client';

import React from 'react';
import Link from 'next/link';
import { Globe, Mail, MessageCircle } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="mt-auto border-t-4 border-black bg-[#FDFDFD] text-black">
      <div className="max-w-7xl mx-auto px-6 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand section */}
          <div className="col-span-1 md:col-span-2">
            <span className="text-2xl font-black uppercase tracking-tighter">
              FleetSync <span className="text-[#FF3131]">AI</span>
            </span>
            <p className="mt-4 text-base font-medium max-w-sm">
              Next-generation fleet management powered by artificial intelligence. 
              Track, optimize, and secure your vehicles in real-time.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-black font-black uppercase mb-4 text-lg">Quick Links</h3>
            <ul className="space-y-3 font-medium">
              <li>
                <Link href="/dashboard" className="hover:text-[#38b6ff] hover:underline decoration-2 transition-colors">Dashboard</Link>
              </li>
              <li>
                <Link href="/analytics" className="hover:text-[#38b6ff] hover:underline decoration-2 transition-colors">Analytics & Reports</Link>
              </li>
              <li>
                <Link href="/store" className="hover:text-[#38b6ff] hover:underline decoration-2 transition-colors">Store & Upgrades</Link>
              </li>
              <li>
                <Link href="#" className="hover:text-[#38b6ff] hover:underline decoration-2 transition-colors">Documentation</Link>
              </li>
              <li>
                <Link href="#" className="hover:text-[#38b6ff] hover:underline decoration-2 transition-colors">API Reference</Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-black font-black uppercase mb-4 text-lg">Connect</h3>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 border-2 border-black bg-[#FFDE59] flex items-center justify-center hover:-translate-y-1 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-all">
                <Globe className="w-5 h-5 text-black" />
              </a>
              <a href="#" className="w-10 h-10 border-2 border-black bg-[#38b6ff] flex items-center justify-center hover:-translate-y-1 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-all">
                <MessageCircle className="w-5 h-5 text-black" />
              </a>
              <a href="#" className="w-10 h-10 border-2 border-black bg-[#FF3131] flex items-center justify-center hover:-translate-y-1 hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-all">
                <Mail className="w-5 h-5 text-black" />
              </a>
            </div>
          </div>
        </div>

        <div className="border-t-4 border-black mt-12 pt-8 flex flex-col md:flex-row justify-between items-center font-bold text-sm">
          <p>&copy; {new Date().getFullYear()} FleetSync AI. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="hover:text-[#FF3131] hover:underline decoration-2 transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-[#FF3131] hover:underline decoration-2 transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
