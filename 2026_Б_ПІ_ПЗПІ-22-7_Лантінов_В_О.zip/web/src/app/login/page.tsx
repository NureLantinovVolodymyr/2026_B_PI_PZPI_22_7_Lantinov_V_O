'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Login failed');

      router.push('/dashboard');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-[#FDFDFD] text-black font-sans relative overflow-x-hidden items-center justify-center p-4">
      {/* Background Dot Pattern */}
      <div 
        className="fixed inset-0 z-0 opacity-20 pointer-events-none"
        style={{ 
          backgroundImage: 'radial-gradient(#000 2px, transparent 2px)', 
          backgroundSize: '24px 24px' 
        }}
      />

      <div className="w-full max-w-md bg-white border-4 border-black p-8 relative z-10 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
        <h1 className="text-4xl font-black uppercase text-center mb-2 tracking-tight">Welcome Back</h1>
        <p className="text-center font-medium mb-8">Access your fleet dashboard</p>

        {error && (
          <div className="bg-[#FF3131] text-white border-4 border-black p-3 rounded-none mb-6 font-bold uppercase shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
            {error}
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <label className="block text-lg font-black uppercase mb-2">Email</label>
            <input
              type="email"
              required
              className="w-full bg-white border-4 border-black p-3 font-medium focus:outline-none focus:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-shadow"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div>
            <label className="block text-lg font-black uppercase mb-2">Password</label>
            <input
              type="password"
              required
              className="w-full bg-white border-4 border-black p-3 font-medium focus:outline-none focus:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-shadow"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 border-4 border-black bg-[#FFDE59] text-xl font-black uppercase tracking-widest hover:bg-[#ffc800] hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 transition-all disabled:opacity-50"
          >
            {loading ? 'Logging in...' : 'Log In'}
          </button>
        </form>

        <p className="text-center mt-6 font-medium">
          Don't have an account?{' '}
          <Link href="/register" className="text-[#38b6ff] font-bold underline decoration-2 hover:text-blue-600 transition-colors">
            Register
          </Link>
        </p>
      </div>
    </div>
  );
}
