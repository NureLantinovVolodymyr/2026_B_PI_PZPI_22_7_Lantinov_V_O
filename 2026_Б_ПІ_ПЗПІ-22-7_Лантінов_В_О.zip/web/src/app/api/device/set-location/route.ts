import { NextResponse } from 'next/server';
import mqtt from 'mqtt';
import { verifyToken } from '@/lib/auth';

const MQTT_HOST = process.env.MQTT_HOST!;
const MQTT_PORT = parseInt(process.env.MQTT_PORT || '8883', 10);
const MQTT_USER = process.env.MQTT_USER!;
const MQTT_PASS = process.env.MQTT_PASS!;

export async function POST(req: Request) {
  try {
    const cookieHeader = req.headers.get('cookie') || '';
    const tokenMatch = cookieHeader.match(/auth-token=([^;]+)/);
    const token = tokenMatch ? tokenMatch[1] : null;

    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const payload = await verifyToken(token);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const { deviceId, lat, lon } = await req.json();

    if (!deviceId || lat === undefined || lon === undefined) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    }

    // Connect to MQTT and publish the new location
    return new Promise((resolve) => {
      const client = mqtt.connect(`mqtts://${MQTT_HOST}:${MQTT_PORT}`, {
        username: MQTT_USER,
        password: MQTT_PASS,
      });

      client.on('connect', () => {
        const topic = `telemetry/${deviceId}/set_location`;
        const message = JSON.stringify({ lat, lon });
        
        client.publish(topic, message, { qos: 1 }, (err) => {
          client.end();
          if (err) {
            console.error('MQTT Publish Error:', err);
            resolve(NextResponse.json({ error: 'Failed to send to device' }, { status: 500 }));
          } else {
            resolve(NextResponse.json({ success: true }));
          }
        });
      });

      client.on('error', (err) => {
        console.error('MQTT Connect Error:', err);
        client.end();
        resolve(NextResponse.json({ error: 'Failed to connect to broker' }, { status: 500 }));
      });
    });
  } catch (error) {
    console.error('Set Location Error:', error);
    return NextResponse.json({ error: 'Failed to sync location' }, { status: 500 });
  }
}
