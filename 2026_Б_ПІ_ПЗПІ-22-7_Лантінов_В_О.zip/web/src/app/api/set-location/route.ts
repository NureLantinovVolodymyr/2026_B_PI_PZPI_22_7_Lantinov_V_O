import { NextResponse } from 'next/server';
import mqtt from 'mqtt';

const MQTT_HOST = process.env.MQTT_HOST || '719e192603794d6882b017dac7fe095c.s1.eu.hivemq.cloud';
const MQTT_PORT = parseInt(process.env.MQTT_PORT || '8883', 10);
const MQTT_USER = process.env.MQTT_USER || 'lun44';
const MQTT_PASS = process.env.MQTT_PASS || '3hDQtURd9juniYJ';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { lat, lon } = body;

    if (lat === undefined || lon === undefined) {
      return NextResponse.json({ error: 'lat and lon are required' }, { status: 400 });
    }

    return new Promise((resolve) => {
      const client = mqtt.connect(`mqtts://${MQTT_HOST}:${MQTT_PORT}`, {
        username: MQTT_USER,
        password: MQTT_PASS,
        protocol: 'mqtts'
      });

      client.on('connect', () => {
        const payload = JSON.stringify({ lat, lon });
        client.publish('commands/truck_01/location', payload, { qos: 1 }, (err) => {
          client.end();
          if (err) {
            console.error('MQTT publish error:', err);
            resolve(NextResponse.json({ error: 'Failed to publish to MQTT' }, { status: 500 }));
          } else {
            resolve(NextResponse.json({ success: true }));
          }
        });
      });

      client.on('error', (err) => {
        console.error('MQTT connection error:', err);
        client.end();
        resolve(NextResponse.json({ error: 'Failed to connect to MQTT broker' }, { status: 500 }));
      });
    });

  } catch (error) {
    console.error('Set location API error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
