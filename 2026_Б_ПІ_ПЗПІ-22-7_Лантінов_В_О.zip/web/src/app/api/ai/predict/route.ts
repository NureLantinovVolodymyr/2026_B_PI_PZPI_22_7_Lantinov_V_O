import { NextResponse } from 'next/server';
import mongoose from 'mongoose';
import User from '@/models/User';
import { verifyToken } from '@/lib/auth';

const MONGODB_URI = process.env.MONGODB_URI!;

export async function POST(req: Request) {
  try {
    const cookieHeader = req.headers.get('cookie') || '';
    const tokenMatch = cookieHeader.match(/auth-token=([^;]+)/);
    const token = tokenMatch ? tokenMatch[1] : null;

    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const payload = await verifyToken(token);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    if (mongoose.connection.readyState === 0) {
      await mongoose.connect(MONGODB_URI);
    }

    const { deviceId } = await req.json();
    if (!deviceId) return NextResponse.json({ error: 'Missing deviceId' }, { status: 400 });

    const user = await User.findById(payload.userId);
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    const device = user.devices.find((d: any) => d.deviceId === deviceId);
    if (!device) return NextResponse.json({ error: 'Device not found' }, { status: 404 });

    // Node.js Backend connecting to Python FastAPI Server
    // Implementing 5-second timeout as required by the negative testing scenario
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);

    try {
      const pyRes = await fetch(`http://127.0.0.1:8001/predict/${deviceId}`, {
        method: 'GET',
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (!pyRes.ok) {
        return NextResponse.json({ error: 'Python AI server returned an error', status: pyRes.status }, { status: 502 });
      }

      const aiData = await pyRes.json();
      
      if (aiData.error) {
         return NextResponse.json({ error: aiData.error }, { status: 400 });
      }

      return NextResponse.json(aiData);

    } catch (fetchError: any) {
      clearTimeout(timeoutId);
      // "Node.js бекенд успішно перехопив помилку, запобігши падінню головного потоку виконання."
      if (fetchError.name === 'AbortError') {
        return NextResponse.json({ 
          error: 'Connection Timeout', 
          details: 'The AI module (FastAPI) did not respond within 5 seconds.' 
        }, { status: 504 });
      }
      return NextResponse.json({ 
        error: 'AI Service Unavailable', 
        details: 'Could not connect to the Python AI server. Please ensure it is running on port 8000.' 
      }, { status: 503 });
    }

  } catch (error) {
    console.error('FastAPI Prediction Error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
