import { NextResponse } from 'next/server';
import mongoose from 'mongoose';
import User from '@/models/User';
import Telemetry from '@/models/Telemetry';
import Trip from '@/models/Trip';
import { verifyToken } from '@/lib/auth';

const GEMINI_API_KEY = process.env.GEMINI_API_KEY!;
const MONGODB_URI = process.env.MONGODB_URI!;

export async function POST(req: Request) {
  try {
    const cookieHeader = req.headers.get('cookie') || '';
    const tokenMatch = cookieHeader.match(/auth-token=([^;]+)/);
    const token = tokenMatch ? tokenMatch[1] : null;

    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const payload = await verifyToken(token);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    if (mongoose.connection.readyState === 0) {
      await mongoose.connect(MONGODB_URI);
    }

    const { deviceId } = await req.json();
    if (!deviceId) return NextResponse.json({ error: 'Missing deviceId' }, { status: 400 });

    const user = await User.findById(payload.userId);
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    const device = user.devices.find((d: any) => d.deviceId === deviceId);
    if (!device) return NextResponse.json({ error: 'Device not found' }, { status: 404 });

    // Fetch latest telemetry
    const telemetry = await Telemetry.find({ deviceId })
      .sort({ timestamp: -1 })
      .limit(10)
      .lean();

    if (telemetry.length === 0) {
      return NextResponse.json({ error: 'No telemetry data available for analysis.' }, { status: 400 });
    }

    const latest = telemetry[0];
    const avgTemp = telemetry.reduce((acc: number, t: any) => acc + t.temperature, 0) / telemetry.length;
    const avgSpeed = telemetry.reduce((acc: number, t: any) => acc + (t.speed || 0), 0) / telemetry.length;

    const promptText = `
You are an expert AI auto mechanic. Analyze the following live telemetry for a ${device.carModel} (Custom name: ${device.customName}).
Current Speed: ${latest.speed?.toFixed(1)} km/h (Avg over last 20s: ${avgSpeed.toFixed(1)} km/h)
Current Engine Temp: ${latest.temperature?.toFixed(1)}°C (Avg over last 20s: ${avgTemp.toFixed(1)}°C)
Current Fuel Level: ${latest.fuel_level?.toFixed(1)}%

Provide a brief, 2-sentence maintenance prediction and driving advice based on this data. Be professional, direct, and slightly analytical. DO NOT format with markdown, just plain text.
    `;

    const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=${GEMINI_API_KEY}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: promptText
              }
            ]
          }
        ]
      })
    });

    if (!res.ok) {
      const errorText = await res.text();
      console.error('Gemini API Error:', errorText);
      return NextResponse.json({ error: 'Failed to generate AI analysis', details: errorText }, { status: 500 });
    }

    const data = await res.json();
    const prediction = data.candidates?.[0]?.content?.parts?.[0]?.text || "Unable to generate prediction at this time.";

    return NextResponse.json({ prediction });
  } catch (error) {
    console.error('AI Analysis Error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
