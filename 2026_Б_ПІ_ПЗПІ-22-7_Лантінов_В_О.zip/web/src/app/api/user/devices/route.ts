import { NextResponse } from 'next/server';
import mongoose from 'mongoose';
import User from '@/models/User';
import { verifyToken } from '@/lib/auth';

const MONGODB_URI = process.env.MONGODB_URI!;

export async function POST(req: Request) {
  try {
    const cookieHeader = req.headers.get('cookie') || '';
    const tokenMatch = cookieHeader.match(/auth-token=([^;]+)/);
    const token = tokenMatch ? tokenMatch[1] : null;

    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    
    const payload = await verifyToken(token);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    if (mongoose.connection.readyState === 0) {
      await mongoose.connect(MONGODB_URI);
    }

    const { deviceId, name, model } = await req.json();

    if (!deviceId || !name || !model) {
      return NextResponse.json({ error: 'Missing fields' }, { status: 400 });
    }

    const user = await User.findById(payload.userId);
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    // Check if device already exists in user's list
    if (user.devices.some((d: any) => d.deviceId === deviceId)) {
      return NextResponse.json({ error: 'Device already added' }, { status: 400 });
    }

    user.devices.push({ deviceId, customName: name, carModel: model });
    await user.save();

    return NextResponse.json({ success: true, devices: user.devices });
  } catch (error) {
    console.error('Add device error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const cookieHeader = req.headers.get('cookie') || '';
    const tokenMatch = cookieHeader.match(/auth-token=([^;]+)/);
    const token = tokenMatch ? tokenMatch[1] : null;

    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const payload = await verifyToken(token);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    if (mongoose.connection.readyState === 0) {
      await mongoose.connect(MONGODB_URI);
    }

    const { deviceId, name, model } = await req.json();

    const user = await User.findById(payload.userId);
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    const device = user.devices.find((d: any) => d.deviceId === deviceId);
    if (!device) {
      return NextResponse.json({ error: 'Device not found' }, { status: 404 });
    }

    if (name) device.customName = name;
    if (model) device.carModel = model;

    await user.save();

    return NextResponse.json({ success: true, devices: user.devices });
  } catch (error) {
    console.error('Devices PUT Error:', error);
    return NextResponse.json({ error: 'Failed to update device' }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const cookieHeader = req.headers.get('cookie') || '';
    const tokenMatch = cookieHeader.match(/auth-token=([^;]+)/);
    const token = tokenMatch ? tokenMatch[1] : null;

    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const payload = await verifyToken(token);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    if (mongoose.connection.readyState === 0) {
      await mongoose.connect(MONGODB_URI);
    }

    const { searchParams } = new URL(req.url);
    const deviceId = searchParams.get('deviceId');

    if (!deviceId) return NextResponse.json({ error: 'Missing deviceId' }, { status: 400 });

    const user = await User.findById(payload.userId);
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    user.devices = user.devices.filter((d: any) => d.deviceId !== deviceId);
    await user.save();

    return NextResponse.json({ success: true, devices: user.devices });
  } catch (error) {
    console.error('Devices DELETE Error:', error);
    return NextResponse.json({ error: 'Failed to delete device' }, { status: 500 });
  }
}
