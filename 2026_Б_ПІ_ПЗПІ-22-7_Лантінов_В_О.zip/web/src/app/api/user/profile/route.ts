import { NextResponse } from 'next/server';
import mongoose from 'mongoose';
import User from '@/models/User';
import { verifyToken } from '@/lib/auth';
import bcrypt from 'bcryptjs';

const MONGODB_URI = process.env.MONGODB_URI!;

export async function PUT(req: Request) {
  try {
    const cookieHeader = req.headers.get('cookie') || '';
    const tokenMatch = cookieHeader.match(/auth-token=([^;]+)/);
    const token = tokenMatch ? tokenMatch[1] : null;

    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const payload = await verifyToken(token);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    if (mongoose.connection.readyState === 0) {
      await mongoose.connect(MONGODB_URI);
    }

    const { nickname, oldPassword, newPassword } = await req.json();

    const user = await User.findById(payload.userId);
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    if (nickname) {
      user.nickname = nickname;
    }

    if (oldPassword && newPassword) {
      const isValid = await bcrypt.compare(oldPassword, user.passwordHash);
      if (!isValid) {
        return NextResponse.json({ error: 'Incorrect old password' }, { status: 400 });
      }
      user.passwordHash = await bcrypt.hash(newPassword, 10);
    }

    await user.save();

    return NextResponse.json({ success: true, nickname: user.nickname });
  } catch (error) {
    console.error('Profile PUT Error:', error);
    return NextResponse.json({ error: 'Failed to update profile' }, { status: 500 });
  }
}
