import { NextResponse } from 'next/server';
import mongoose from 'mongoose';
import Telemetry from '@/models/Telemetry';
import User from '@/models/User';
import { verifyToken } from '@/lib/auth';

const MONGODB_URI = process.env.MONGODB_URI!;

export async function GET(req: Request) {
  try {
    const cookieHeader = req.headers.get('cookie') || '';
    const tokenMatch = cookieHeader.match(/auth-token=([^;]+)/);
    const token = tokenMatch ? tokenMatch[1] : null;

    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const payload = await verifyToken(token);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    if (mongoose.connection.readyState === 0) {
      await mongoose.connect(MONGODB_URI);
    }

    const user = await User.findById(payload.userId);
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    const deviceIds = user.devices.map((d: any) => d.deviceId);

    const telemetry = await Telemetry.find({ deviceId: { $in: deviceIds } })
      .sort({ timestamp: -1 })
      .limit(100)
      .lean();

    return NextResponse.json(telemetry);
  } catch (error) {
    console.error('API Error:', error);
    return NextResponse.json({ error: 'Failed to fetch telemetry' }, { status: 500 });
  }
}
