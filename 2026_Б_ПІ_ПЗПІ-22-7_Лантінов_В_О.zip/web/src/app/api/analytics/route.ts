import { NextResponse } from 'next/server';
import mongoose from 'mongoose';
import User from '@/models/User';
import Telemetry from '@/models/Telemetry';
import { verifyToken } from '@/lib/auth';

const MONGODB_URI = process.env.MONGODB_URI!;

export async function GET(req: Request) {
  try {
    const cookieHeader = req.headers.get('cookie') || '';
    const tokenMatch = cookieHeader.match(/auth-token=([^;]+)/);
    const token = tokenMatch ? tokenMatch[1] : null;

    if (!token) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const payload = await verifyToken(token);
    if (!payload) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (mongoose.connection.readyState === 0) {
      await mongoose.connect(MONGODB_URI);
    }

    const user = await User.findById(payload.userId);
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

    const deviceIds = user.devices.map((d: any) => d.deviceId);
    
    // Fetch up to 500 data points for charting, sorted oldest to newest (ascending)
    const data = await Telemetry.find({ deviceId: { $in: deviceIds } })
      .sort({ timestamp: 1 })
      .limit(500)
      .lean();

    return NextResponse.json(data);
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
