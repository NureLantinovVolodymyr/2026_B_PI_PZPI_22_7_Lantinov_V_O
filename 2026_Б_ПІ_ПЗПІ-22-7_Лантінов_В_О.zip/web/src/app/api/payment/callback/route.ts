import { NextResponse } from 'next/server';
import crypto from 'crypto';
import mongoose from 'mongoose';
import Order from '@/models/Order';
import User from '@/models/User';

const PRIVATE_KEY = process.env.LIQPAY_PRIVATE_KEY!;
const MONGODB_URI = process.env.MONGODB_URI!;

export async function POST(req: Request) {
  try {
    const formData = await req.formData();
    const data = formData.get('data') as string;
    const signature = formData.get('signature') as string;

    if (!data || !signature) return NextResponse.json({ error: 'Missing parameters' }, { status: 400 });

    const signString = PRIVATE_KEY + data + PRIVATE_KEY;
    const expectedSignature = crypto.createHash('sha3-256').update(signString).digest('base64');

    if (signature !== expectedSignature) {
      return NextResponse.json({ error: 'Invalid signature' }, { status: 400 });
    }

    const decodedData = JSON.parse(Buffer.from(data, 'base64').toString('utf8'));
    
    if (mongoose.connection.readyState === 0) await mongoose.connect(MONGODB_URI);

    if (decodedData.status === 'success' || decodedData.status === 'sandbox') {
      const order = await Order.findOneAndUpdate(
        { orderId: decodedData.order_id },
        { status: 'success' },
        { new: true }
      );

      if (order && order.type === 'subscription') {
        await User.findByIdAndUpdate(order.userId, { subscriptionType: 'premium' });
      }
    } else {
      await Order.findOneAndUpdate(
        { orderId: decodedData.order_id },
        { status: 'failure' }
      );
    }

    return NextResponse.json({ status: 'ok' });
  } catch (error) {
    console.error('Callback error', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
