import { NextResponse } from 'next/server';
import crypto from 'crypto';
import mongoose from 'mongoose';
import Order from '@/models/Order';
import { verifyToken } from '@/lib/auth';

const PUBLIC_KEY = process.env.LIQPAY_PUBLIC_KEY!;
const PRIVATE_KEY = process.env.LIQPAY_PRIVATE_KEY!;
const MONGODB_URI = process.env.MONGODB_URI!;

export async function POST(req: Request) {
  try {
    const cookieHeader = req.headers.get('cookie') || '';
    const tokenMatch = cookieHeader.match(/auth-token=([^;]+)/);
    const token = tokenMatch ? tokenMatch[1] : null;

    if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    const payload = await verifyToken(token);
    if (!payload) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    if (mongoose.connection.readyState === 0) await mongoose.connect(MONGODB_URI);

    const body = await req.json();
    const { type, amount, deliveryDetails } = body;
    
    const orderId = `ORDER_${Date.now()}_${Math.floor(Math.random() * 1000)}`;

    await Order.create({
      userId: payload.userId,
      orderId,
      type,
      amount,
      deliveryDetails
    });

    // In production, server_url must be your real domain
    const jsonString = JSON.stringify({
      public_key: PUBLIC_KEY,
      version: 7,
      action: "pay",
      amount: amount,
      currency: "UAH",
      description: type === 'subscription' ? 'Premium AI Subscription' : 'New GPS Tracker Device',
      order_id: orderId,
      result_url: "http://localhost:3000/store?success=true",
      server_url: "http://localhost:3000/api/payment/callback" 
    });

    const data = Buffer.from(jsonString).toString('base64');
    const signString = PRIVATE_KEY + data + PRIVATE_KEY;
    const signature = crypto.createHash('sha3-256').update(signString).digest('base64');

    return NextResponse.json({ data, signature });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
