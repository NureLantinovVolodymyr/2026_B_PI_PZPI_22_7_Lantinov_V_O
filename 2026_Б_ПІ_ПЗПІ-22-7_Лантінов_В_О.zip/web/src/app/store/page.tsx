'use client';

import React, { useState, useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { ShoppingCart, Zap, Package, ChevronLeft, CheckCircle2 } from 'lucide-react';

export default function StorePage() {
  const [loading, setLoading] = useState(false);
  const [showDeviceModal, setShowDeviceModal] = useState(false);
  const [delivery, setDelivery] = useState({ fullName: '', phone: '', address: '', comments: '' });
  const [successMessage, setSuccessMessage] = useState('');
  
  const router = useRouter();
  const searchParams = useSearchParams();

  useEffect(() => {
    if (searchParams.get('success') === 'true') {
      setSuccessMessage('Payment successful! Your order has been placed.');
    }
  }, [searchParams]);

  const handleCheckout = async (type: 'subscription' | 'device') => {
    if (type === 'device' && (!delivery.fullName || !delivery.phone || !delivery.address)) {
      alert("Please fill in all required delivery fields.");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch('/api/payment/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          type,
          amount: type === 'subscription' ? 500 : 1500,
          deliveryDetails: type === 'device' ? delivery : undefined
        })
      });
      
      const { data, signature, error } = await res.json();
      if (error) throw new Error(error);

      // Submit form to LiqPay
      const form = document.createElement('form');
      form.method = 'POST';
      form.action = 'https://www.liqpay.ua/api/3/checkout';
      
      const dataInput = document.createElement('input');
      dataInput.type = 'hidden';
      dataInput.name = 'data';
      dataInput.value = data;
      
      const sigInput = document.createElement('input');
      sigInput.type = 'hidden';
      sigInput.name = 'signature';
      sigInput.value = signature;

      form.appendChild(dataInput);
      form.appendChild(sigInput);
      document.body.appendChild(form);
      form.submit();

    } catch (error) {
      console.error('Checkout failed', error);
      alert('Checkout failed, please try again.');
      setLoading(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-[#FDFDFD] text-black font-sans relative overflow-x-hidden">
      {/* Background Dot Pattern */}
      <div 
        className="fixed inset-0 z-0 opacity-20 pointer-events-none"
        style={{ 
          backgroundImage: 'radial-gradient(#000 2px, transparent 2px)', 
          backgroundSize: '24px 24px' 
        }}
      />

      <nav className="relative z-10 border-b-4 border-black bg-white sticky top-0 p-4 flex items-center">
        <button onClick={() => router.push('/dashboard')} className="flex items-center text-black font-black uppercase hover:underline decoration-2 transition-colors mr-6">
          <ChevronLeft className="w-6 h-6 mr-1 stroke-[3]" /> Back to Dashboard
        </button>
        <span className="text-2xl font-black uppercase tracking-tighter">
          FleetSync <span className="text-[#FF3131]">Store</span>
        </span>
      </nav>

      <main className="relative z-10 max-w-5xl mx-auto px-6 py-12">
        {successMessage && (
          <div className="bg-[#FFDE59] border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] p-4 flex items-center space-x-4 mb-8">
            <CheckCircle2 className="w-8 h-8 text-black stroke-[3]" />
            <p className="text-black font-black uppercase text-lg">{successMessage}</p>
          </div>
        )}

        <div className="grid md:grid-cols-2 gap-8">
          {/* AI Subscription Card */}
          <div className="bg-white border-4 border-black p-8 relative flex flex-col shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-2 hover:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] transition-all">
            <div className="w-16 h-16 border-4 border-black bg-[#FF3131] flex items-center justify-center mb-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              <Zap className="w-8 h-8 text-white stroke-[3]" />
            </div>
            <h2 className="text-3xl font-black uppercase tracking-tight mb-2 text-black">Premium AI Subscription</h2>
            <p className="font-medium text-lg mb-6 flex-1 text-black">
              Unlock advanced predictive maintenance, route optimization, and unlimited AI analytics for all your vehicles.
            </p>
            <div className="mb-8">
              <span className="text-5xl font-black">500 ₴</span>
              <span className="text-xl font-bold"> / month</span>
            </div>
            <button 
              onClick={() => handleCheckout('subscription')}
              disabled={loading}
              className="w-full py-4 border-4 border-black bg-[#38b6ff] text-black font-black uppercase text-xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:bg-[#20a8f8] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all flex items-center justify-center"
            >
              {loading ? 'Processing...' : 'Subscribe Now'}
            </button>
          </div>

          {/* New Device Card */}
          <div className="bg-white border-4 border-black p-8 relative flex flex-col shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-2 hover:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] transition-all">
            <div className="w-16 h-16 border-4 border-black bg-[#FFDE59] flex items-center justify-center mb-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              <Package className="w-8 h-8 text-black stroke-[3]" />
            </div>
            <h2 className="text-3xl font-black uppercase tracking-tight mb-2 text-black">Additional GPS Tracker</h2>
            <p className="font-medium text-lg mb-6 flex-1 text-black">
              Expand your fleet with our high-precision telemetry device. Plugs directly into OBD2 port. Free delivery across Ukraine.
            </p>
            <div className="mb-8">
              <span className="text-5xl font-black">1,500 ₴</span>
              <span className="text-xl font-bold"> one-time</span>
            </div>
            <button 
              onClick={() => setShowDeviceModal(true)}
              className="w-full py-4 border-4 border-black bg-[#FF3131] text-white font-black uppercase text-xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:bg-[#e02828] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all flex items-center justify-center"
            >
              <ShoppingCart className="w-6 h-6 mr-3 stroke-[3]" /> Buy Device
            </button>
          </div>
        </div>
      </main>

      {/* Delivery Details Modal */}
      {showDeviceModal && (
        <div className="fixed inset-0 bg-[#FDFDFD]/90 backdrop-blur-sm z-[9999] flex items-center justify-center p-4">
          <div className="bg-white border-4 border-black p-8 w-full max-w-md relative shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
            <h2 className="text-3xl font-black uppercase mb-2 text-black tracking-tight">
              Delivery Details
            </h2>
            <p className="font-bold text-black mb-6">Please enter your shipping information.</p>
            
            <div className="space-y-4 mb-8">
              <div>
                <label className="text-sm font-black uppercase text-black block mb-1">Full Name *</label>
                <input type="text" required
                  className="w-full bg-white border-4 border-black p-3 font-bold placeholder-gray-500 focus:outline-none focus:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-shadow text-black"
                  value={delivery.fullName} onChange={e => setDelivery({...delivery, fullName: e.target.value})}
                />
              </div>
              <div>
                <label className="text-sm font-black uppercase text-black block mb-1">Phone Number *</label>
                <input type="tel" required
                  className="w-full bg-white border-4 border-black p-3 font-bold placeholder-gray-500 focus:outline-none focus:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-shadow text-black"
                  value={delivery.phone} onChange={e => setDelivery({...delivery, phone: e.target.value})}
                />
              </div>
              <div>
                <label className="text-sm font-black uppercase text-black block mb-1">Delivery Address (Nova Poshta) *</label>
                <input type="text" required
                  className="w-full bg-white border-4 border-black p-3 font-bold placeholder-gray-500 focus:outline-none focus:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-shadow text-black"
                  value={delivery.address} onChange={e => setDelivery({...delivery, address: e.target.value})}
                />
              </div>
              <div>
                <label className="text-sm font-black uppercase text-black block mb-1">Comments (Optional)</label>
                <textarea 
                  className="w-full bg-white border-4 border-black p-3 font-bold placeholder-gray-500 focus:outline-none focus:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-shadow text-black h-24 resize-none"
                  value={delivery.comments} onChange={e => setDelivery({...delivery, comments: e.target.value})}
                />
              </div>
            </div>

            <div className="flex space-x-4">
              <button onClick={() => setShowDeviceModal(false)} className="flex-1 py-4 border-4 border-black bg-gray-200 hover:bg-gray-300 text-black font-black uppercase transition-colors shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                Cancel
              </button>
              <button 
                onClick={() => handleCheckout('device')}
                disabled={loading}
                className="flex-1 py-4 border-4 border-black bg-[#FFDE59] hover:bg-[#ffc800] text-black font-black uppercase transition-colors shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]"
              >
                {loading ? 'Processing...' : 'Pay'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
