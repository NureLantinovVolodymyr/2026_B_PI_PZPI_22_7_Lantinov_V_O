'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Activity, TrendingUp, Fuel, Thermometer, ChevronLeft, BrainCircuit, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { AreaChart, Area, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

export default function AnalyticsDashboard() {
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [prediction, setPrediction] = useState<any>(null);
  const [isPredicting, setIsPredicting] = useState(false);
  const [predictError, setPredictError] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const fetchAnalytics = async () => {
      try {
        const res = await fetch('/api/analytics');
        if (!res.ok) {
          router.push('/login');
          return;
        }
        const telemetry = await res.json();
        
        // Format the data for recharts
        const formatted = telemetry.map((t: any) => {
          const date = new Date(t.timestamp || t.ts || Date.now());
          return {
            ...t,
            timeLabel: date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            speed: t.speed || 0,
            fuel: t.fuel_level || 0,
            temp: t.temperature || 0,
          };
        });
        
        setData(formatted);
      } catch (err) {
        console.error("Failed to fetch analytics", err);
      } finally {
        setLoading(false);
      }
    };

    fetchAnalytics();
  }, [router]);

  if (loading) {
    return <div className="h-screen bg-[#FDFDFD] text-black font-black uppercase text-2xl flex items-center justify-center">Loading Analytics...</div>;
  }

  // Calculate strict KPI from existing data
  const avgSpeed = data.length > 0 ? (data.reduce((acc, curr) => acc + curr.speed, 0) / data.length).toFixed(1) : '0.0';
  const avgTemp = data.length > 0 ? (data.reduce((acc, curr) => acc + curr.temp, 0) / data.length).toFixed(1) : '0.0';
  const latestFuel = data.length > 0 ? data[data.length - 1].fuel.toFixed(1) : '0.0';
  const totalPoints = data.length;

  const handlePredict = async () => {
    if (data.length === 0) return;
    // Get the most recent device ID
    const deviceId = data[data.length - 1].deviceId;
    
    setIsPredicting(true);
    setPredictError(null);
    setPrediction(null);
    
    try {
      const res = await fetch('/api/ai/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ deviceId })
      });
      const aiData = await res.json();
      
      if (!res.ok) {
        setPredictError(aiData.error + (aiData.details ? `: ${aiData.details}` : ''));
      } else {
        setPrediction(aiData);
      }
    } catch (err) {
      setPredictError("Failed to reach Node.js backend.");
    } finally {
      setIsPredicting(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col bg-[#FDFDFD] text-black font-sans relative overflow-x-hidden">
      {/* Background Dot Pattern */}
      <div 
        className="fixed inset-0 z-0 opacity-20 pointer-events-none"
        style={{ 
          backgroundImage: 'radial-gradient(#000 2px, transparent 2px)', 
          backgroundSize: '24px 24px' 
        }}
      />

      <nav className="relative z-10 border-b-4 border-black bg-white sticky top-0 p-4 flex items-center justify-between">
        <button onClick={() => router.push('/dashboard')} className="flex items-center text-black font-black uppercase hover:underline decoration-2 transition-colors">
          <ChevronLeft className="w-6 h-6 mr-1 stroke-[3]" /> Back to Dashboard
        </button>
        <div className="text-2xl font-black uppercase tracking-tighter">
          Fleet <span className="text-[#38b6ff]">Analytics</span>
        </div>
      </nav>

      <main className="relative z-10 max-w-7xl mx-auto px-6 py-8 space-y-8">
        
        {/* KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-[#FFDE59] border-4 border-black p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transition-all">
            <div className="text-sm font-black uppercase mb-2 flex items-center text-black">
              <Activity className="w-5 h-5 mr-2 stroke-[3]" /> Avg Speed
            </div>
            <p className="text-5xl font-black">{avgSpeed} <span className="text-xl font-bold">km/h</span></p>
          </div>
          <div className="bg-white border-4 border-black p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transition-all">
            <div className="text-sm font-black uppercase mb-2 flex items-center text-black">
              <Fuel className="w-5 h-5 mr-2 stroke-[3]" /> Latest Fuel Level
            </div>
            <p className="text-5xl font-black">{latestFuel}%</p>
          </div>
          <div className="bg-[#FF3131] border-4 border-black p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transition-all text-white">
            <div className="text-sm font-black uppercase mb-2 flex items-center text-white">
              <Thermometer className="w-5 h-5 mr-2 stroke-[3]" /> Avg Temp
            </div>
            <p className="text-5xl font-black">{avgTemp}°C</p>
          </div>
          <div className="bg-[#38b6ff] border-4 border-black p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transition-all">
            <div className="text-sm font-black uppercase mb-2 flex items-center text-black">
              <TrendingUp className="w-5 h-5 mr-2 stroke-[3]" /> Data Points
            </div>
            <p className="text-5xl font-black">{totalPoints}</p>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Speed Chart */}
          <div className="bg-white border-4 border-black p-6 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
            <h3 className="text-2xl font-black uppercase tracking-tight mb-6 text-black border-b-4 border-black pb-2 inline-block">Speed Over Time</h3>
            {data.length === 0 ? (
              <div className="h-64 flex items-center justify-center font-bold text-gray-500 border-2 border-black border-dashed">No telemetry data found in DB.</div>
            ) : (
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={data}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e5e5" vertical={false} />
                    <XAxis dataKey="timeLabel" stroke="#000" fontSize={12} tickMargin={10} fontWeight="bold" />
                    <YAxis stroke="#000" fontSize={12} fontWeight="bold" />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#fff', borderColor: '#000', borderWidth: '4px', borderRadius: '0px', boxShadow: '4px 4px 0px 0px rgba(0,0,0,1)' }}
                      itemStyle={{ color: '#000', fontWeight: '900', textTransform: 'uppercase' }}
                    />
                    <Line type="monotone" dataKey="speed" stroke="#38b6ff" strokeWidth={4} dot={{ strokeWidth: 2, r: 4, fill: '#fff', stroke: '#000' }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>

          {/* Fuel Chart */}
          <div className="bg-white border-4 border-black p-6 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
            <h3 className="text-2xl font-black uppercase tracking-tight mb-6 text-black border-b-4 border-black pb-2 inline-block">Fuel Level Trend</h3>
            {data.length === 0 ? (
              <div className="h-64 flex items-center justify-center font-bold text-gray-500 border-2 border-black border-dashed">No telemetry data found in DB.</div>
            ) : (
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={data}>
                    <defs>
                      <linearGradient id="colorFuel" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#FFDE59" stopOpacity={0.8}/>
                        <stop offset="95%" stopColor="#FFDE59" stopOpacity={0.2}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e5e5" vertical={false} />
                    <XAxis dataKey="timeLabel" stroke="#000" fontSize={12} tickMargin={10} fontWeight="bold" />
                    <YAxis stroke="#000" fontSize={12} fontWeight="bold" />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#fff', borderColor: '#000', borderWidth: '4px', borderRadius: '0px', boxShadow: '4px 4px 0px 0px rgba(0,0,0,1)' }}
                      itemStyle={{ color: '#000', fontWeight: '900', textTransform: 'uppercase' }}
                    />
                    <Area type="monotone" dataKey="fuel" stroke="#FFDE59" strokeWidth={4} fillOpacity={1} fill="url(#colorFuel)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>

        </div>

        {/* FastAPI Predictive Maintenance Panel */}
        <div className="bg-black text-white border-4 border-black p-8 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
            <div>
              <h3 className="text-3xl font-black uppercase tracking-tight mb-2 flex items-center">
                <BrainCircuit className="w-8 h-8 mr-3 text-[#FFDE59]" />
                Predictive Maintenance (FastAPI)
              </h3>
              <p className="font-bold text-gray-300">
                Run advanced ML models (Gradient Boosting & Isolation Forest) to detect anomalies and predict Remaining Useful Life.
              </p>
            </div>
            <button 
              onClick={handlePredict}
              disabled={isPredicting || data.length === 0}
              className="bg-[#FFDE59] text-black border-4 border-black px-8 py-4 font-black uppercase text-xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 transition-all disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap"
            >
              {isPredicting ? 'Analyzing...' : 'Run Diagnostics'}
            </button>
          </div>

          {predictError && (
            <div className="bg-[#FF3131] border-4 border-black p-4 flex items-start space-x-4 mb-4 text-white">
              <AlertTriangle className="w-6 h-6 shrink-0 stroke-[3]" />
              <div className="font-bold uppercase tracking-wide">{predictError}</div>
            </div>
          )}

          {prediction && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              <div className={`border-4 border-black p-6 flex flex-col justify-center space-y-4 ${prediction.is_anomaly ? 'bg-[#FF3131]' : 'bg-[#38b6ff]'}`}>
                <div className="flex items-center space-x-6">
                  <div className="w-16 h-16 bg-white border-4 border-black flex items-center justify-center shrink-0 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                    {prediction.is_anomaly ? (
                      <AlertTriangle className="w-8 h-8 text-[#FF3131] stroke-[3]" />
                    ) : (
                      <CheckCircle2 className="w-8 h-8 text-[#38b6ff] stroke-[3]" />
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-black uppercase text-black">System Status</p>
                    <p className="text-3xl font-black text-black leading-tight">
                      {prediction.is_anomaly ? 'ANOMALY DETECTED' : 'OPERATING NORMALLY'}
                    </p>
                  </div>
                </div>
                <div className="bg-white/90 border-2 border-black p-3 text-black font-medium">
                  {prediction.is_anomaly 
                    ? "Critical variance detected in telemetry patterns. Isolation Forest algorithm has flagged abnormal behavior likely caused by suspension impacts or severe engine overheat. Immediate inspection is recommended."
                    : "All telemetry vectors are within normal operational thresholds. The Isolation Forest algorithm confirms stable engine and suspension behavior. No immediate action required."}
                  {prediction.metrics && (
                    <div className="mt-2 text-sm font-bold border-t-2 border-black pt-2 flex justify-between">
                      <span>Avg Temp: {prediction.metrics.avg_temp}°C</span>
                      <span>Vibration Var: {prediction.metrics.vibration_variance.toFixed(2)}</span>
                    </div>
                  )}
                </div>
              </div>
              
              <div className="bg-white border-4 border-black p-6 flex flex-col justify-center space-y-4">
                <div className="flex items-center space-x-6">
                  <div className="w-16 h-16 bg-[#FFDE59] border-4 border-black flex items-center justify-center shrink-0 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                    <Activity className="w-8 h-8 text-black stroke-[3]" />
                  </div>
                  <div>
                    <p className="text-sm font-black uppercase text-black">Remaining Useful Life (RUL)</p>
                    <p className="text-4xl font-black text-black">
                      {prediction.days_to_maintenance} <span className="text-xl">Days</span>
                    </p>
                  </div>
                </div>
                <div className="bg-gray-100 border-2 border-black p-3 text-black font-medium">
                  Estimated by the Gradient Boosting ensemble model based on historical engine temperature and vibration degradation. Schedule preventive maintenance before this period ends to minimize downtime.
                </div>
              </div>
            </div>
          )}
        </div>

      </main>
    </div>
  );
}
