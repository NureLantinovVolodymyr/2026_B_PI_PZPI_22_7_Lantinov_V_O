'use client';

import React, { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import MapComponent from '@/components/MapComponent';
import CitySearch from '@/components/CitySearch';
import DeviceManager from '@/components/DeviceManager';
import { Activity, Thermometer, Fuel, Map as MapIcon, AlertTriangle, LogOut, Gauge, Navigation, Trash2 } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';

export default function Dashboard() {
  const [telemetry, setTelemetry] = useState<any[]>([]);
  const [trips, setTrips] = useState<any[]>([]);
  const [places, setPlaces] = useState<any[]>([]);
  const [user, setUser] = useState<any>(null);
  const [selectedPlace, setSelectedPlace] = useState<any>(null);
  const [newPlaceName, setNewPlaceName] = useState('');
  const [isSyncing, setIsSyncing] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const [showProfile, setShowProfile] = useState(false);
  const [profileNickname, setProfileNickname] = useState('');
  const [oldPassword, setOldPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [profileMessage, setProfileMessage] = useState('');
  const router = useRouter();

  const fetchAuthAndData = async () => {
    try {
      const authRes = await fetch('/api/auth/me');
      if (!authRes.ok) {
        router.push('/login');
        return;
      }
      const authData = await authRes.json();
      setUser(authData.user);

      const telRes = await fetch('/api/telemetry');
      const telData = await telRes.json();
      if (Array.isArray(telData)) setTelemetry(telData);

      const tripRes = await fetch('/api/trips');
      const tripData = await tripRes.json();
      if (Array.isArray(tripData)) setTrips(tripData);

      const placesRes = await fetch('/api/places');
      const placesData = await placesRes.json();
      if (Array.isArray(placesData)) setPlaces(placesData);
    } catch (err) {
      console.error("Failed to fetch data", err);
    }
  };

  useEffect(() => {
    fetchAuthAndData();
    const interval = setInterval(fetchAuthAndData, 2000);
    return () => clearInterval(interval);
  }, []);

  const handleLogout = async () => {
    await fetch('/api/auth/logout', { method: 'POST' });
    router.push('/login');
  };

  const handlePlaceClick = (place: any) => {
    setSelectedPlace(place);
    setNewPlaceName(place.name);
  };

  const handleRenamePlace = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedPlace) return;
    try {
      const res = await fetch('/api/places', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ placeId: selectedPlace._id, name: newPlaceName })
      });
      if (res.ok) {
        setSelectedPlace(null);
        fetchAuthAndData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleDeletePlace = async () => {
    if (!selectedPlace) return;
    try {
      const res = await fetch(`/api/places?placeId=${selectedPlace._id}`, { method: 'DELETE' });
      if (res.ok) {
        setSelectedPlace(null);
        fetchAuthAndData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleSyncLocation = () => {
    if (!latest) return;
    setIsSyncing(true);
    if ("geolocation" in navigator) {
      navigator.geolocation.getCurrentPosition(async (position) => {
        const { latitude, longitude } = position.coords;
        try {
          await fetch('/api/device/set-location', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ deviceId: latest.deviceId, lat: latitude, lon: longitude })
          });
        } catch (err) {
          console.error(err);
        }
        setIsSyncing(false);
      }, (err) => {
        console.error(err);
        setIsSyncing(false);
      });
    } else {
      setIsSyncing(false);
    }
  };

  const handleAnalyzeAI = async () => {
    if (!latest) return;
    setIsAnalyzing(true);
    try {
      const res = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ deviceId: latest.deviceId })
      });
      const data = await res.json();
      if (!res.ok) {
        console.error("AI Analysis Error HTTP", res.status, data.error);
        if (data.details) {
          console.error("Google Gemini responded with:", data.details);
          // Set it as analysis text so the user can see it on screen too
          setAiAnalysis(`API Error: ${data.details}`);
        }
      } else if (data.prediction) {
        setAiAnalysis(data.prediction);
      }
    } catch (err) {
      console.error("Network/Fetch error:", err);
    }
    setIsAnalyzing(false);
  };

  const openProfile = () => {
    setProfileNickname(user?.nickname || '');
    setOldPassword('');
    setNewPassword('');
    setProfileMessage('');
    setShowProfile(true);
  };

  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setProfileMessage('Saving...');
    try {
      const res = await fetch('/api/user/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nickname: profileNickname, oldPassword, newPassword })
      });
      const data = await res.json();
      if (res.ok) {
        setProfileMessage('Profile updated!');
        fetchAuthAndData();
        setTimeout(() => setShowProfile(false), 1500);
      } else {
        setProfileMessage(data.error || 'Failed to update');
      }
    } catch (err) {
      setProfileMessage('Error updating profile');
    }
  };

  if (!user) return <div className="h-screen bg-[#FDFDFD] text-black font-black uppercase text-2xl flex items-center justify-center">Loading...</div>;

  const latest = telemetry.length > 0 ? telemetry[0] : null;

  // Mock historical data for the chart based on current telemetry to make it look dynamic
  const mockChartData = Array.from({ length: 20 }).map((_, i) => ({
    time: i,
    temp: latest ? latest.temperature + (Math.random() * 2 - 1) : 20,
    fuel: latest ? latest.fuel_level - (i * 0.1) : 100,
  })).reverse();

  // Filter newest telemetry for each device for the map
  const latestPerDevice = telemetry.filter((t, index, self) =>
    index === self.findIndex((i) => i.deviceId === t.deviceId)
  );

  return (
    <div className="flex-1 flex flex-col bg-[#FDFDFD] text-black font-sans relative overflow-x-hidden">
      {/* Background Dot Pattern */}
      <div
        className="fixed inset-0 z-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: 'radial-gradient(#000 2px, transparent 2px)',
          backgroundSize: '24px 24px'
        }}
      />

      <nav className="relative z-10 border-b-4 border-black bg-white sticky top-0 p-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-12">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 border-2 border-black bg-[#FFDE59] flex items-center justify-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <MapIcon className="w-6 h-6 text-black" />
              </div>
              <span className="text-2xl font-black uppercase tracking-tighter">
                FleetSync <span className="text-[#38b6ff]">AI</span>
              </span>
            </div>
            <div className="flex items-center space-x-6">
              <button onClick={() => router.push('/analytics')} className="text-lg font-black uppercase text-black hover:underline decoration-2 transition-colors">
                Analytics
              </button>
              <button onClick={() => router.push('/store')} className="text-lg font-black uppercase text-[#FF3131] hover:underline decoration-2 transition-colors">
                Store
              </button>
              <button onClick={openProfile} className="text-lg font-black uppercase text-black hover:underline decoration-2 transition-colors hidden sm:block">
                {user.nickname || user.email} {user.subscriptionType === 'premium' && '🌟'}
              </button>
              <DeviceManager devices={user.devices} onDeviceAdded={fetchAuthAndData} />
              <button onClick={handleLogout} className="p-2 border-2 border-black bg-white shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-0.5 hover:bg-[#FF3131] hover:text-white transition-all text-black">
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Alerts */}
        {latest && latest.fuel_level < 20 && (
          <div className="bg-[#FF3131] border-4 border-black p-4 flex items-center space-x-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
            <AlertTriangle className="w-8 h-8 text-white stroke-[3]" />
            <p className="text-xl font-black uppercase text-white">Warning: Low fuel! Please refuel soon.</p>
          </div>
        )}

        {/* Top Stats Row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="bg-white border-4 border-black p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transition-all">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-black uppercase text-black">Speed</p>
                <p className="text-4xl font-black text-black mt-1">{latest?.speed ? latest.speed.toFixed(0) : '0'} <span className="text-xl font-bold">km/h</span></p>
              </div>
              <div className="w-12 h-12 border-4 border-black bg-[#38b6ff] flex items-center justify-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <Gauge className="w-6 h-6 text-black stroke-[3]" />
              </div>
            </div>
          </div>

          <div className="bg-white border-4 border-black p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transition-all">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-black uppercase text-black">Engine Temp</p>
                <p className="text-4xl font-black text-black mt-1">{latest ? latest.temperature.toFixed(1) : '--'}°C</p>
              </div>
              <div className="w-12 h-12 border-4 border-black bg-[#FF3131] flex items-center justify-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <Thermometer className="w-6 h-6 text-white stroke-[3]" />
              </div>
            </div>
          </div>

          <div className="bg-white border-4 border-black p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transition-all">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-black uppercase text-black">Fuel Level</p>
                <p className="text-4xl font-black text-black mt-1">{latest ? latest.fuel_level.toFixed(0) : '--'}%</p>
              </div>
              <div className="w-12 h-12 border-4 border-black bg-[#FFDE59] flex items-center justify-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <Fuel className="w-6 h-6 text-black stroke-[3]" />
              </div>
            </div>
          </div>

          <div className="bg-white border-4 border-black p-6 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] transition-all">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-black uppercase text-black">Active Status</p>
                <p className="text-4xl font-black mt-1 text-[#38b6ff]">
                  {latest?.speed > 0 ? 'Driving' : 'Idle'}
                </p>
              </div>
              <div className="w-12 h-12 border-4 border-black bg-black flex items-center justify-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                <Activity className="w-6 h-6 text-white stroke-[3]" />
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-4">
            <CitySearch />
            <div className="bg-white border-4 border-black p-2 relative h-[500px] shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
              <div className="absolute top-6 left-6 z-10 flex flex-col space-y-3">
                <div className="bg-white border-4 border-black px-4 py-2 flex items-center space-x-3 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                  <div className="w-3 h-3 border-2 border-black bg-[#FF3131] animate-pulse"></div>
                  <span className="text-sm font-black text-black uppercase tracking-wider">Live Tracking Active</span>
                </div>
                {latest && (
                  <button
                    onClick={handleSyncLocation}
                    disabled={isSyncing}
                    className="bg-[#FFDE59] border-4 border-black px-4 py-3 flex items-center space-x-2 transition-all shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 text-black"
                  >
                    <Navigation className={`w-5 h-5 stroke-[3] ${isSyncing ? 'animate-spin' : ''}`} />
                    <span className="text-sm font-black uppercase tracking-wider">
                      {isSyncing ? 'Locating...' : 'Sync to My Location'}
                    </span>
                  </button>
                )}
              </div>
              <MapComponent telemetry={latestPerDevice} places={places} onPlaceClick={handlePlaceClick} />
            </div>
          </div>

          {/* Charts & AI Predictions Panel */}
          <div className="space-y-8 flex flex-col h-full">
            <div className="bg-white border-4 border-black p-6 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] flex-1 flex flex-col min-h-[300px]">
              <h3 className="text-2xl font-black uppercase tracking-tight mb-6 text-black border-b-4 border-black pb-2 inline-block flex items-center">
                <Thermometer className="w-6 h-6 mr-2 stroke-[3]" />
                Temperature Trend
              </h3>
              <div className="flex-1 w-full h-full min-h-0">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={mockChartData}>
                    <defs>
                      <linearGradient id="colorTemp" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#FF3131" stopOpacity={0.8} />
                        <stop offset="95%" stopColor="#FF3131" stopOpacity={0.2} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e5e5e5" vertical={false} />
                    <XAxis dataKey="time" hide />
                    <YAxis domain={['auto', 'auto']} hide />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#fff', borderColor: '#000', borderWidth: '4px', borderRadius: '0px', boxShadow: '4px 4px 0px 0px rgba(0,0,0,1)' }}
                      itemStyle={{ color: '#000', fontWeight: '900', textTransform: 'uppercase' }}
                    />
                    <Area type="monotone" dataKey="temp" stroke="#FF3131" strokeWidth={4} fillOpacity={1} fill="url(#colorTemp)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Predictive Maintenance Alert */}
            <div className="bg-[#38b6ff] border-4 border-black p-6 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] mt-auto text-black">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 border-4 border-black bg-white flex items-center justify-center shrink-0 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                    <AlertTriangle className="w-6 h-6 text-black stroke-[3]" />
                  </div>
                  <h3 className="text-1.9xl font-black uppercase tracking-tight">AI Prediction</h3>
                </div>
                <button
                  onClick={handleAnalyzeAI}
                  disabled={isAnalyzing || !latest}
                  className="bg-white border-4 border-black text-black font-black uppercase py-2 px-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 transition-all"
                >
                  {isAnalyzing ? 'Analyzing...' : 'Analyze'}
                </button>
              </div>
              <div className="font-bold text-lg leading-relaxed bg-white border-4 border-black p-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] whitespace-pre-line">
                {aiAnalysis || (user.devices.length > 0
                  ? "Click 'Analyze' to get real-time AI insights for your vehicle."
                  : 'Add a device to see AI predictions.')}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Rename Place Modal */}
      {selectedPlace && (
        <div className="fixed inset-0 bg-[#FDFDFD]/90 backdrop-blur-sm z-[9999] flex items-center justify-center p-4">
          <div className="bg-white border-4 border-black p-8 w-full max-w-sm relative shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
            <button onClick={() => setSelectedPlace(null)} className="absolute top-4 right-4 text-black hover:scale-110 transition-transform">
              <LogOut className="w-6 h-6 rotate-45 stroke-[3]" />
            </button>
            <h2 className="text-3xl font-black uppercase mb-2 text-black flex items-center">
              <span className="mr-3">❤️</span> Rename
            </h2>
            <p className="font-bold text-black mb-6">Give a custom name to this favorite stop.</p>

            <form onSubmit={handleRenamePlace}>
              <input
                type="text"
                autoFocus
                required
                className="w-full bg-white border-4 border-black p-4 font-bold focus:outline-none focus:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-shadow mb-6 text-black"
                value={newPlaceName}
                onChange={e => setNewPlaceName(e.target.value)}
              />
              <div className="flex space-x-4 mb-4">
                <button type="button" onClick={() => setSelectedPlace(null)} className="flex-1 py-4 border-4 border-black bg-gray-200 hover:bg-gray-300 text-black font-black uppercase shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-colors">
                  Cancel
                </button>
                <button type="submit" className="flex-1 py-4 border-4 border-black bg-[#38b6ff] hover:bg-[#20a8f8] text-black font-black uppercase shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-colors">
                  Save
                </button>
              </div>
              <button type="button" onClick={handleDeletePlace} className="w-full py-4 border-4 border-black bg-[#FF3131] hover:bg-[#e02828] text-white font-black uppercase shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-colors flex items-center justify-center">
                <Trash2 className="w-6 h-6 mr-3 stroke-[3]" /> Delete Place
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Profile Settings Modal */}
      {showProfile && (
        <div className="fixed inset-0 bg-[#FDFDFD]/90 backdrop-blur-sm z-[9999] flex items-center justify-center p-4">
          <div className="bg-white border-4 border-black p-8 w-full max-w-sm relative shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
            <button onClick={() => setShowProfile(false)} className="absolute top-4 right-4 text-black hover:scale-110 transition-transform">
              <LogOut className="w-6 h-6 rotate-45 stroke-[3]" />
            </button>
            <h2 className="text-3xl font-black uppercase tracking-tight mb-6 text-black">Profile Settings</h2>

            <form onSubmit={handleProfileSave} className="space-y-6">
              <div>
                <label className="text-sm font-black uppercase text-black block mb-2">Nickname</label>
                <input
                  type="text"
                  className="w-full bg-white border-4 border-black p-3 font-bold focus:outline-none focus:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-shadow text-black"
                  value={profileNickname}
                  onChange={e => setProfileNickname(e.target.value)}
                />
              </div>
              <div>
                <label className="text-sm font-black uppercase text-black block mb-2">Change Password</label>
                <input
                  type="password" placeholder="Old Password"
                  className="w-full bg-white border-4 border-black p-3 font-bold mb-3 focus:outline-none focus:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-shadow text-black placeholder-gray-500"
                  value={oldPassword}
                  onChange={e => setOldPassword(e.target.value)}
                />
                <input
                  type="password" placeholder="New Password"
                  className="w-full bg-white border-4 border-black p-3 font-bold focus:outline-none focus:shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] transition-shadow text-black placeholder-gray-500"
                  value={newPassword}
                  onChange={e => setNewPassword(e.target.value)}
                />
              </div>

              {profileMessage && <p className="text-black font-black uppercase border-2 border-black border-dashed p-2 text-center bg-[#FFDE59] shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">{profileMessage}</p>}

              <button type="submit" className="w-full py-4 border-4 border-black bg-[#38b6ff] hover:bg-[#20a8f8] text-black font-black uppercase shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:-translate-y-1 hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all">
                Save Profile
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
