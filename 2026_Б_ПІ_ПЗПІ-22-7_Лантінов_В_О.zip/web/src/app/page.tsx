'use client';

import React, { useRef } from 'react';
import { useRouter } from 'next/navigation';
import { motion, useScroll, useTransform } from 'framer-motion';
import { ArrowRight, Zap, Shield, Globe } from 'lucide-react';

export default function LandingPage() {
  const router = useRouter();
  const containerRef = useRef<HTMLDivElement>(null);

  const sectionRef = useRef<HTMLElement>(null);

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ["start center", "end center"]
  });

  const pathLength = useTransform(scrollYProgress, [0, 0.8], [0, 1]);

  return (
    <div className="flex-1 flex flex-col bg-[#FDFDFD] text-black font-sans relative overflow-x-hidden" ref={containerRef}>
      {/* Background Dot Pattern */}
      <div 
        className="fixed inset-0 z-0 opacity-20 pointer-events-none"
        style={{ 
          backgroundImage: 'radial-gradient(#000 2px, transparent 2px)', 
          backgroundSize: '24px 24px' 
        }}
      />

      {/* Navigation */}
      <nav className="relative z-10 border-b-4 border-black bg-white">
        <div className="max-w-7xl mx-auto px-6 h-20 flex items-center justify-between">
          <div className="text-3xl font-black tracking-tighter uppercase">
            FleetSync <span className="text-[#FF3131]">AI</span>
          </div>
          <motion.button 
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => router.push('/login')}
            className="border-4 border-black bg-[#FFDE59] px-6 py-2 font-bold text-lg shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-shadow"
          >
            Log In
          </motion.button>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="relative z-10 max-w-7xl mx-auto px-6 pt-32 pb-24 text-center">
        <motion.h1 
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, type: 'spring' }}
          className="text-6xl md:text-8xl font-black uppercase tracking-tight leading-none mb-8"
        >
          From Idea To <br />
          <span className="bg-[#38b6ff] text-white px-4 py-2 border-4 border-black inline-block transform -rotate-2 mt-4 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
            Automated Workflow
          </span>
        </motion.h1>
        
        <motion.p 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="text-xl md:text-2xl font-medium max-w-2xl mx-auto mb-12 border-2 border-black bg-white p-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]"
        >
          Next-generation fleet management powered by artificial intelligence. Track, optimize, and secure your vehicles in real-time.
        </motion.p>

        <motion.button
          whileHover={{ scale: 1.05, y: -4 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => router.push('/login')}
          className="group relative inline-flex items-center justify-center border-4 border-black bg-[#FF3131] text-white px-10 py-5 text-2xl font-black uppercase tracking-wide shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] transition-all"
        >
          Get Started
          <ArrowRight className="ml-4 w-8 h-8 group-hover:translate-x-2 transition-transform" />
        </motion.button>
      </main>

      {/* Infinite Ticker */}
      <div className="relative z-10 border-y-4 border-black bg-[#FFDE59] overflow-hidden py-4 flex whitespace-nowrap">
        <motion.div 
          animate={{ x: [0, -1000] }}
          transition={{ repeat: Infinity, duration: 20, ease: "linear" }}
          className="flex font-black text-3xl uppercase tracking-widest"
        >
          {Array(10).fill('REAL-TIME TRACKING • AI PREDICTIONS • AUTOMATED WORKFLOWS • ').map((text, i) => (
            <span key={i} className="mx-4">{text}</span>
          ))}
        </motion.div>
      </div>

      {/* Features Grid */}
      <section className="relative z-10 max-w-7xl mx-auto px-6 py-32">
        <h2 className="text-5xl font-black uppercase text-center mb-16 border-b-4 border-black pb-4 inline-block">What We Offer</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Feature 1 */}
          <motion.div 
            whileHover={{ y: -10 }}
            className="border-4 border-black bg-white p-8 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] relative"
          >
            <div className="absolute -top-6 -left-6 border-4 border-black bg-[#FFDE59] w-12 h-12 flex items-center justify-center font-black text-xl shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              01
            </div>
            <Zap className="w-12 h-12 mb-6" />
            <h3 className="text-2xl font-black uppercase mb-4">Instant Tracking</h3>
            <p className="font-medium text-lg">Pinpoint your fleet's location anywhere in the world with zero latency updates.</p>
          </motion.div>

          {/* Feature 2 */}
          <motion.div 
            whileHover={{ y: -10 }}
            className="border-4 border-black bg-white p-8 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] relative"
          >
            <div className="absolute -top-6 -left-6 border-4 border-black bg-[#38b6ff] w-12 h-12 flex items-center justify-center font-black text-xl text-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              02
            </div>
            <Shield className="w-12 h-12 mb-6" />
            <h3 className="text-2xl font-black uppercase mb-4">AI Maintenance</h3>
            <p className="font-medium text-lg">Predict failures before they happen using our advanced machine learning models.</p>
          </motion.div>

          {/* Feature 3 */}
          <motion.div 
            whileHover={{ y: -10 }}
            className="border-4 border-black bg-white p-8 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] relative"
          >
            <div className="absolute -top-6 -left-6 border-4 border-black bg-[#FF3131] w-12 h-12 flex items-center justify-center font-black text-xl text-white shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              03
            </div>
            <Globe className="w-12 h-12 mb-6" />
            <h3 className="text-2xl font-black uppercase mb-4">Global Reach</h3>
            <p className="font-medium text-lg">Manage unlimited vehicles across borders with unified dashboard analytics.</p>
          </motion.div>
        </div>
      </section>

      {/* How It Works - SVG Drawing Animation */}
      <section ref={sectionRef} className="relative z-10 max-w-3xl mx-auto px-6 py-32 text-center">
        <h2 className="text-5xl font-black uppercase mb-24">How It Works</h2>
        
        <div className="relative">
          {/* Animated SVG Line replacement with motion.div */}
          <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-[4px] bg-gray-200 z-0 hidden md:block">
            <motion.div 
              className="w-full bg-black origin-top"
              style={{ scaleY: pathLength, height: '100%' }}
            />
          </div>

          <div className="space-y-24 relative z-10 w-full max-w-5xl mx-auto">
            {/* Step 1 */}
            <div className="grid grid-cols-1 md:grid-cols-2 items-center relative w-full gap-8 md:gap-0">
              <div className="flex md:justify-end md:pr-16 w-full justify-center">
                <motion.div whileHover={{ scale: 1.05 }} className="border-4 border-black bg-white p-8 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] text-center md:text-right relative z-20 w-full max-w-[450px]">
                  <h3 className="text-4xl font-black uppercase mb-4">Connect</h3>
                  <p className="font-bold text-xl">Plug in your devices to sync instantly.</p>
                </motion.div>
              </div>
              <div className="absolute left-1/2 -translate-x-1/2 w-8 h-8 rounded-full border-4 border-black bg-[#FFDE59] z-30 hidden md:block" />
              <div className="hidden md:block"></div>
            </div>

            {/* Step 2 */}
            <div className="grid grid-cols-1 md:grid-cols-2 items-center relative w-full gap-8 md:gap-0">
              <div className="hidden md:block"></div>
              <div className="absolute left-1/2 -translate-x-1/2 w-8 h-8 rounded-full border-4 border-black bg-[#38b6ff] z-30 hidden md:block" />
              <div className="flex md:justify-start md:pl-16 w-full justify-center">
                <motion.div whileHover={{ scale: 1.05 }} className="border-4 border-black bg-white p-8 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] text-center md:text-left relative z-20 w-full max-w-[450px]">
                  <h3 className="text-4xl font-black uppercase mb-4">Automate</h3>
                  <p className="font-bold text-xl">Let AI monitor and predict outcomes.</p>
                </motion.div>
              </div>
            </div>

            {/* Step 3 */}
            <div className="grid grid-cols-1 md:grid-cols-2 items-center relative w-full gap-8 md:gap-0">
              <div className="flex md:justify-end md:pr-16 w-full justify-center">
                <motion.div whileHover={{ scale: 1.05 }} className="border-4 border-black bg-white p-8 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] text-center md:text-right relative z-20 w-full max-w-[450px]">
                  <h3 className="text-4xl font-black uppercase mb-4">Scale</h3>
                  <p className="font-bold text-xl">Grow your fleet without limits.</p>
                </motion.div>
              </div>
              <div className="absolute left-1/2 -translate-x-1/2 w-8 h-8 rounded-full border-4 border-black bg-[#FF3131] z-30 hidden md:block" />
              <div className="hidden md:block"></div>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}
