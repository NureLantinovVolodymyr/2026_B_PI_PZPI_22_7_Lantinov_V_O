import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  const token = request.cookies.get('auth-token')?.value;
  const { pathname } = request.nextUrl;

  // Protect dashboard, store, and analytics
  if (pathname.startsWith('/dashboard') || pathname.startsWith('/store') || pathname.startsWith('/analytics')) {
    if (!token) {
      return NextResponse.redirect(new URL('/', request.url));
    }
  }

  // Redirect authenticated users away from landing and login page directly to dashboard
  if (pathname === '/' || pathname === '/login') {
    if (token) {
      return NextResponse.redirect(new URL('/dashboard', request.url));
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ['/', '/login', '/dashboard/:path*', '/store/:path*', '/analytics/:path*'],
};
