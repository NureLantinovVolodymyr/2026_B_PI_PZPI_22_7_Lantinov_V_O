import mongoose, { Schema, Document } from 'mongoose';

export interface IPlace extends Document {
  userId: mongoose.Types.ObjectId;
  deviceId: string;
  location: {
    lat: number;
    lon: number;
  };
  name: string;
  visits: number;
  isFavorite: boolean;
  lastVisit: Date;
}

const PlaceSchema: Schema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  deviceId: { type: String, required: true },
  location: {
    lat: { type: Number, required: true },
    lon: { type: Number, required: true }
  },
  name: { type: String, default: 'Favorite Place' },
  visits: { type: Number, default: 1 },
  isFavorite: { type: Boolean, default: false },
  lastVisit: { type: Date, default: Date.now }
});

export default mongoose.models.Place || mongoose.model<IPlace>('Place', PlaceSchema);
