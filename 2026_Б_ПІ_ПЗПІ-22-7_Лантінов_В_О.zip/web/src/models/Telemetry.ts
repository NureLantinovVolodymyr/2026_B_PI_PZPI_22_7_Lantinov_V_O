import mongoose, { Schema, Document } from 'mongoose';

export interface ITelemetry extends Document {
  deviceId: string;
  gps: {
    lat: number;
    lon: number;
  };
  accel: {
    x: number;
    y: number;
    z: number;
  };
  temperature: number;
  fuel_level: number;
  speed: number;
  timestamp: Date;
}

const TelemetrySchema: Schema = new Schema({
  deviceId: { type: String, required: true },
  gps: {
    lat: { type: Number, required: true },
    lon: { type: Number, required: true }
  },
  accel: {
    x: { type: Number, required: true },
    y: { type: Number, required: true },
    z: { type: Number, required: true }
  },
  temperature: { type: Number, required: true },
  fuel_level: { type: Number, required: true },
  speed: { type: Number, default: 0 },
  timestamp: { type: Date, default: Date.now }
});

export default mongoose.models.Telemetry || mongoose.model<ITelemetry>('Telemetry', TelemetrySchema);
