import mongoose, { Schema, Document } from 'mongoose';

export interface IDevice {
  deviceId: string;
  name: string;
  model: string;
}

export interface IUser extends Document {
  email: string;
  passwordHash: string;
  nickname?: string;
  devices: IDevice[];
  createdAt: Date;
}

const DeviceSchema = new Schema({
  deviceId: { type: String, required: true },
  name: { type: String, required: true },
  model: { type: String, required: true }
});

const UserSchema: Schema = new Schema({
  email: { type: String, required: true, unique: true },
  passwordHash: { type: String, required: true },
  nickname: { type: String, default: 'Driver' },
  subscriptionType: { type: String, enum: ['free', 'premium'], default: 'free' },
  devices: { type: [DeviceSchema], default: [] },
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.models.User || mongoose.model<IUser>('User', UserSchema);
