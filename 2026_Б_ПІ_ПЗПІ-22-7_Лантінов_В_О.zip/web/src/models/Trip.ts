import mongoose, { Schema, Document } from 'mongoose';

export interface ITrip extends Document {
  deviceId: string;
  startTime: Date;
  endTime?: Date;
  status: 'active' | 'completed';
  startLocation?: { lat: number; lon: number };
  endLocation?: { lat: number; lon: number };
}

const TripSchema: Schema = new Schema({
  deviceId: { type: String, required: true },
  startTime: { type: Date, required: true, default: Date.now },
  endTime: { type: Date },
  status: { type: String, enum: ['active', 'completed'], default: 'active' },
  startLocation: {
    lat: { type: Number },
    lon: { type: Number }
  },
  endLocation: {
    lat: { type: Number },
    lon: { type: Number }
  }
});

export default mongoose.models.Trip || mongoose.model<ITrip>('Trip', TripSchema);
