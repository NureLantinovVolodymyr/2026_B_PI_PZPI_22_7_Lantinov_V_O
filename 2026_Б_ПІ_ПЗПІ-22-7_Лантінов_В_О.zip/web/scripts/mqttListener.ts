import mqtt from 'mqtt';
import mongoose from 'mongoose';
import dotenv from 'dotenv';
import Telemetry from '../src/models/Telemetry';
import Trip from '../src/models/Trip';
import Place from '../src/models/Place';
import User from '../src/models/User';

// Load env variables
dotenv.config();

const MONGODB_URI = process.env.MONGODB_URI!;
const MQTT_HOST = process.env.MQTT_HOST!;
const MQTT_PORT = parseInt(process.env.MQTT_PORT || '8883', 10);
const MQTT_USER = process.env.MQTT_USER!;
const MQTT_PASS = process.env.MQTT_PASS!;
const MAPBOX_TOKEN = process.env.NEXT_PUBLIC_MAPBOX_TOKEN!;

async function snapToRoad(lon: number, lat: number): Promise<{lon: number, lat: number}> {
  if (!MAPBOX_TOKEN) return { lon, lat };
  try {
    // Mapbox Directions API requires at least 2 coordinates, so we pass the same point twice
    // It returns 'waypoints' which contain the coordinate snapped to the nearest road network
    const url = `https://api.mapbox.com/directions/v5/mapbox/driving/${lon},${lat};${lon},${lat}?access_token=${MAPBOX_TOKEN}`;
    const res = await fetch(url);
    const data = await res.json();
    if (data.waypoints && data.waypoints.length > 0) {
      return {
        lon: data.waypoints[0].location[0],
        lat: data.waypoints[0].location[1]
      };
    }
  } catch (err) {
    console.error("Snap to road API error:", err);
  }
  return { lon, lat };
}

const IDLE_VARIANCE_THRESHOLD = 0.5; // Threshold for engine rest
const START_AMPLITUDE_THRESHOLD = 2.0; // Jump threshold
const STOP_TIMEOUT_MS = 60 * 1000;

// State tracking per device
interface DeviceState {
  isActive: boolean;
  lastActiveTime: number;
  accelHistory: number[];
  currentTripId?: string;
  lastSpeed: number;
  lastTemp: number;
  stopStartTime: number;
  hasRegistered10s: boolean;
  hasRegistered30s: boolean;
}
const deviceStates: Record<string, DeviceState> = {};

async function init() {
  await mongoose.connect(MONGODB_URI);
  console.log('Connected to MongoDB');

  const client = mqtt.connect(`mqtts://${MQTT_HOST}:${MQTT_PORT}`, {
    username: MQTT_USER,
    password: MQTT_PASS,
  });

  client.on('connect', () => {
    console.log('Connected to HiveMQ');
    client.subscribe('telemetry/+', (err) => {
      if (!err) {
        console.log('Subscribed to telemetry topic');
      }
    });
    client.subscribe('telemetry/+/request_location', (err) => {
      if (!err) {
        console.log('Subscribed to request_location topic');
      }
    });
  });

  client.on('message', async (topic, message) => {
    try {
      if (topic.endsWith('/request_location')) {
        const parts = topic.split('/');
        if (parts.length >= 3) {
          const deviceId = parts[1];
          const lastTelemetry = await Telemetry.findOne({ deviceId }).sort({ timestamp: -1 });
          if (lastTelemetry && lastTelemetry.gps) {
            client.publish(`telemetry/${deviceId}/set_location`, JSON.stringify({
              lat: lastTelemetry.gps.lat,
              lon: lastTelemetry.gps.lon
            }));
            console.log(`[${deviceId}] Sent last known location to device.`);
          }
        }
        return;
      }

      const payload = JSON.parse(message.toString());
      const { deviceId, accel, temperature, fuel_level, speed } = payload;
      let { gps } = payload;
      
      // Snap GPS to nearest road before saving
      if (gps && gps.lon && gps.lat) {
        gps = await snapToRoad(gps.lon, gps.lat);
      }

      // Save Telemetry
      await Telemetry.create({
        deviceId,
        gps,
        accel,
        temperature,
        fuel_level,
        speed: speed || 0,
      });

      // Analyze Acceleration
      const vectorAccel = Math.sqrt(accel.x * accel.x + accel.y * accel.y + accel.z * accel.z);
      
      let state = deviceStates[deviceId];
      if (!state) {
        state = { 
          isActive: false, lastActiveTime: Date.now(), accelHistory: [],
          lastSpeed: speed || 0, lastTemp: temperature, stopStartTime: 0,
          hasRegistered10s: false, hasRegistered30s: false
        };
        deviceStates[deviceId] = state;
      }

      // Check Stop Condition for Favorite Places
      if ((speed || 0) === 0 && Math.abs(temperature - state.lastTemp) < 0.5) {
        if (state.stopStartTime === 0) {
          state.stopStartTime = Date.now();
          state.hasRegistered10s = false;
          state.hasRegistered30s = false;
        } else {
          const stopDuration = Date.now() - state.stopStartTime;
          
          if (stopDuration >= 10000 && !state.hasRegistered10s) {
            console.log(`[${deviceId}] Stopped for 10s. Registering stop.`);
            state.hasRegistered10s = true;
            const user = await User.findOne({ "devices.deviceId": deviceId });
            if (user && gps) {
              const nearbyPlace = await Place.findOne({
                userId: user._id,
                "location.lat": { $gte: gps.lat - 0.0005, $lte: gps.lat + 0.0005 },
                "location.lon": { $gte: gps.lon - 0.0005, $lte: gps.lon + 0.0005 }
              });

              if (nearbyPlace) {
                nearbyPlace.visits += 1;
                nearbyPlace.lastVisit = new Date();
                if (nearbyPlace.visits >= 10) nearbyPlace.isFavorite = true;
                await nearbyPlace.save();
              } else {
                await Place.create({
                  userId: user._id,
                  deviceId,
                  location: gps,
                  visits: 1
                });
              }
            }
          }
          
          if (stopDuration >= 30000 && !state.hasRegistered30s) {
             console.log(`[${deviceId}] Stopped for 30s. Marking favorite.`);
             state.hasRegistered30s = true;
             const user = await User.findOne({ "devices.deviceId": deviceId });
             if (user && gps) {
               const nearbyPlace = await Place.findOne({
                 userId: user._id,
                 "location.lat": { $gte: gps.lat - 0.0005, $lte: gps.lat + 0.0005 },
                 "location.lon": { $gte: gps.lon - 0.0005, $lte: gps.lon + 0.0005 }
               });
               if (nearbyPlace && !nearbyPlace.isFavorite) {
                 nearbyPlace.isFavorite = true;
                 await nearbyPlace.save();
               }
             }
          }
        }
      } else {
        state.stopStartTime = 0;
        state.hasRegistered10s = false;
        state.hasRegistered30s = false;
      }

      state.lastSpeed = speed || 0;
      state.lastTemp = temperature;

      state.accelHistory.push(vectorAccel);
      if (state.accelHistory.length > 20) {
        state.accelHistory.shift(); // Keep last 20 readings for variance
      }

      const mean = state.accelHistory.reduce((a, b) => a + b, 0) / state.accelHistory.length;
      const variance = state.accelHistory.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / state.accelHistory.length;

      const now = Date.now();

      // Basic Earth gravity is ~9.8 m/s^2. Deviation implies movement/vibration.
      if (!state.isActive) {
        // Check for start: Amplitude jump + high variance
        if (Math.abs(vectorAccel - 9.8) > START_AMPLITUDE_THRESHOLD || variance > IDLE_VARIANCE_THRESHOLD) {
          console.log(`[${deviceId}] Engine started! Variance: ${variance.toFixed(2)}`);
          state.isActive = true;
          state.lastActiveTime = now;
          
          const newTrip = await Trip.create({
            deviceId,
            startTime: new Date(),
            startLocation: gps,
            status: 'active'
          });
          state.currentTripId = newTrip._id.toString();
        }
      } else {
        // Currently active
        if (variance > IDLE_VARIANCE_THRESHOLD) {
          state.lastActiveTime = now; // Engine is vibrating, update time
        } else {
          // Check for stop: Low variance for > 60 seconds
          if (now - state.lastActiveTime > STOP_TIMEOUT_MS) {
            console.log(`[${deviceId}] Engine stopped! Low variance for 60s.`);
            state.isActive = false;
            
            if (state.currentTripId) {
              await Trip.findByIdAndUpdate(state.currentTripId, {
                endTime: new Date(),
                endLocation: gps,
                status: 'completed'
              });
              state.currentTripId = undefined;
            }
          }
        }
      }
    } catch (err) {
      console.error('Error processing message', err);
    }
  });
}

init().catch(console.error);
