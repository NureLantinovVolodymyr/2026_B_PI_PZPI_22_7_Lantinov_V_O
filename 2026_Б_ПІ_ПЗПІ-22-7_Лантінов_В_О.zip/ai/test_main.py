import pytest
import warnings
import numpy as np
from fastapi.testclient import TestClient
from main import app, gb_model, iso_forest

# Suppress httpx DeprecationWarnings for a clean test output
warnings.filterwarnings("ignore", category=DeprecationWarning)

client = TestClient(app)

# ---------------------------------------------------------
# 1. ML Model Unit Tests
# ---------------------------------------------------------
def test_gradient_boosting_model_prediction():
    """Перевірка того, що модель Gradient Boosting повертає адекватний прогноз (RUL)."""
    # Нормальні показники: Температура 85, Пальне 50, Вібрація 0.5
    normal_features = np.array([[85.0, 50.0, 0.5]])
    rul = gb_model.predict(normal_features)[0]
    
    assert rul > 0, "Залишковий ресурс має бути більше 0 для нормальних даних"
    assert rul < 150, "Залишковий ресурс не повинен перевищувати адекватні межі"

def test_isolation_forest_anomaly_detection():
    """Перевірка Isolation Forest на коректне виявлення аномалій (негативний сценарій)."""
    # Нормальні показники
    normal_features = np.array([[80.0, 50.0, 0.5]])
    is_normal = iso_forest.predict(normal_features)[0]
    assert is_normal == 1, "Модель повинна визначити ці дані як нормальні (1)"

    # Аномальні показники: Різкий скачок вібрації (удари по підвісці) та перегрів
    anomaly_features = np.array([[120.0, 50.0, 9.5]])
    is_anomaly = iso_forest.predict(anomaly_features)[0]
    assert is_anomaly == -1, "Модель повинна виявити аномалію (-1) через критичні показники"

# ---------------------------------------------------------
# 2. FastAPI Endpoint Integration Tests
# ---------------------------------------------------------
def test_api_predict_missing_device():
    """Перевірка, що API коректно обробляє запит з неіснуючим пристроєм або відсутністю даних."""
    response = client.get("/predict/unknown_device_999")
    # Оскільки в MongoDB немає `unknown_device_999`, має повернутись 200 OK з помилкою в JSON
    assert response.status_code == 200
    assert "error" in response.json()
    assert response.json()["error"] == "Not enough telemetry data for prediction"

# Note: We can't easily test the successful API response without mocking the MongoDB 
# connection in this single file. But testing the ML models and the API error handling 
# already provides a robust verification suite for the diploma thesis!
