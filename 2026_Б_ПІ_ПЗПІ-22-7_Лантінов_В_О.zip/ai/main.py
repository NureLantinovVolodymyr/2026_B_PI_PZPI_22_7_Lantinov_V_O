import os
import numpy as np
import pandas as pd
from fastapi import FastAPI
from motor.motor_asyncio import AsyncIOMotorClient
from sklearn.ensemble import GradientBoostingRegressor, IsolationForest
from dotenv import load_dotenv
from contextlib import asynccontextmanager

load_dotenv()

MONGODB_URI = os.getenv("MONGODB_URI", "mongodb+srv://volodymyrlantinov_db_user:GeogyOygi9yW3GxG@main.zpydmyn.mongodb.net/fleet_tracking?retryWrites=true&w=majority")
client = AsyncIOMotorClient(MONGODB_URI)
db = client.fleet_tracking

# Initialize dummy models
# In a real scenario, these would be trained and loaded from disk (e.g. joblib)
# Gradient Boosting for Remaining Useful Life (RUL) estimation
gb_model = GradientBoostingRegressor(n_estimators=100, random_state=42)
# Isolation Forest for Anomaly Detection (Vibration/Temp spikes)
iso_forest = IsolationForest(contamination=0.05, random_state=42)

# Create realistic training data so the models behave deterministically
np.random.seed(42)
# Normal operational data (stable temp, low vibration)
normal_temp = np.random.normal(80, 5, 80)
normal_fuel = np.random.uniform(0, 100, 80)
normal_var = np.random.exponential(0.5, 80)
X_normal = np.column_stack((normal_temp, normal_fuel, normal_var))
y_normal = np.random.randint(40, 120, 80) # High remaining useful life

# Anomaly data 1: Engine Overheat
anomaly_temp_high = np.random.normal(115, 5, 10)
anomaly_fuel_1 = np.random.uniform(0, 100, 10)
anomaly_var_1 = np.random.exponential(0.5, 10)
X_anomaly1 = np.column_stack((anomaly_temp_high, anomaly_fuel_1, anomaly_var_1))

# Anomaly data 2: Suspension Hits (High variance)
anomaly_temp_2 = np.random.normal(80, 5, 10)
anomaly_fuel_2 = np.random.uniform(0, 100, 10)
anomaly_var_high = np.random.normal(8.0, 2.0, 10)
X_anomaly2 = np.column_stack((anomaly_temp_2, anomaly_fuel_2, anomaly_var_high))

X_train_gb = np.vstack((X_normal, X_anomaly1, X_anomaly2))
y_train_gb = np.concatenate((y_normal, np.random.randint(1, 5, 20))) # Low remaining life for anomalies

# Train Gradient Boosting on all data to learn RUL
gb_model.fit(X_train_gb, y_train_gb)

# Train Isolation Forest mostly on normal data to detect outliers later
# Train Isolation Forest mostly on normal data to detect outliers later
iso_forest.fit(X_normal)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Verify DB connection on startup
    try:
        await client.admin.command('ping')
        print("Connected to MongoDB from AI Service.")
    except Exception as e:
        print("Unable to connect to MongoDB:", e)
    yield
    # Close DB connection on shutdown
    client.close()

app = FastAPI(title="FleetSync AI Service", description="Predictive Maintenance AI", lifespan=lifespan)

@app.get("/")
def read_root():
    return {"status": "ok", "service": "FleetSync AI"}

@app.get("/predict/{device_id}")
async def predict_maintenance(device_id: str):
    # Fetch latest telemetry for the device
    telemetry_cursor = db.telemetries.find({"deviceId": device_id}).sort("timestamp", -1).limit(50)
    data = await telemetry_cursor.to_list(length=50)
    
    if not data or len(data) < 5:
        return {"error": "Not enough telemetry data for prediction"}
        
    # Extract features
    df = pd.DataFrame(data)
    
    # Calculate vibration variance approximation
    df['accel_norm'] = np.sqrt(df.apply(lambda row: row['accel']['x']**2 + row['accel']['y']**2 + row['accel']['z']**2, axis=1))
    recent_variance = df['accel_norm'].var()
    avg_temp = df['temperature'].mean()
    avg_fuel = df['fuel_level'].mean()
    
    # Handle NaN variance if needed
    if pd.isna(recent_variance):
        recent_variance = 0.0
        
    features = np.array([[avg_temp, avg_fuel, recent_variance]])
    
    # Predict RUL (Remaining Useful Life) in days
    days_to_maintenance = gb_model.predict(features)[0]
    
    # Anomaly Detection
    is_anomaly = iso_forest.predict(features)[0] == -1
    
    return {
        "device_id": device_id,
        "days_to_maintenance": int(round(days_to_maintenance)),
        "is_anomaly": bool(is_anomaly),
        "metrics": {
            "avg_temp": round(avg_temp, 2),
            "vibration_variance": round(recent_variance, 4)
        }
    }
